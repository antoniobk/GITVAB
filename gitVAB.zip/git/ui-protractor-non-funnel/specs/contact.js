var navigation = require('../pageObjects/navigation.js');
var contact = require('../pageObjects/contact.js');
browser.waitForAngularEnabled(false);

describe('Contact: Sending a message with the contact form ', function () {



	it('Contact: Open browser, & accept cookies', function () {
		console.log("Contact: Navigating to contact page..");
        navigation.get();
        navigation.acceptCookies();
    });

    it('Contact: Filling in user data', function() {
        console.log("Contact: filling in user data");
        contact.fillUserData();
    });

    it('Contact: Selecting a subject', function(){
        console.log("Contact: Selecting a subject");
        contact.selectSubject();
    });
    
    it('Contact: Writing a message', function(){
        console.log("Contact: Writing a message");
        contact.writingMessage();
    });

    it('Contact: Validating CAPTCHA', function(){
        console.log("Contact: Validating CAPTCHA");
        contact.captchaValidation();
    });

    it('Contact: Sending message', function(){
        console.log("Contact: Sending message");
        contact.sendMessage();
    });


});
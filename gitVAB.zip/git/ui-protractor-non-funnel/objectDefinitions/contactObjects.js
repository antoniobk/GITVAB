module.exports = function() {
    
    this.nameField = element(by.xpath('//*[@id="LastName"]'));
    this.surNameField = element(by.xpath('//*[@id="FirstName"]'));
    this.emailField = element(by.xpath('//*[@id="Email"]'));
    this.subjectField = element(by.xpath('//*[@id="SelectedEmail"]'));
    this.messageField = element(by.xpath('//*[@id="Message"]'));
    this.iamnotarobotCheckbox = element(by.xpath('//*[@id="recaptcha-anchor"]/div[1]'));
    this.sendButton = element(by.xpath('//*[@id="contact-wrapper"]/form/div[4]/button'));
    this.thankyouMessage = element(by.xpath('//*[@id="thankYou"]/div[1]/div/div'));

    //testdata
    this.name = "Automatische-Test-User-Familienaam";
    this.surname = "Automatische-Test-User-Voornaam";
    this.email = "automatische-Test-User-Email@vab.be";
    this.message = "This is an automated test.";
    
}

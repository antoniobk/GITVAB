module.exports = function() {
    this. acceptCookieBtn = element(by.xpath("/html/body/div/div[2]/div[4]/a[2]"));
}
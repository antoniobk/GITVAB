var navigationObjects = require('../objectDefinitions/navigationObjects.js')
var Navigation = function () {

var navigationObject = new navigationObjects();

    this.get = function () {
		console.log("Navigation: get");
        browser.get("https://acc.vab.be");
        browser.sleep(5000);
        element(by.xpath("//a[@gtmlabel='Contact']")).click();
        browser.sleep(3000);
    };

    this.acceptCookies = function () {
		console.log("Navigation: acceptCookies");
        navigationObject.acceptCookieBtn.click();
        browser.sleep(5000);
    };
};
module.exports = new Navigation();
var contactObjects = require('../objectDefinitions/contactObjects')
var Contact = function () {
var contact = new contactObjects();

this.fillUserData = function() {
    console.log("contact: filling in user data");
    contact.nameField.sendKeys(contact.name);
    contact.surNameField.sendKeys(contact.surname);
    contact.emailField.sendKeys(contact.email);
    browser.sleep(3000);   
};

this.selectSubject = function() {
    console.log("Contact: selecting a subject");
    var max = 13;
    var min = 2;
    var randomSubject = Math.floor((Math.random() * ((max + 1) - min)) + min);
    contact.subjectField.click();
    element(by.xpath('//*[@id="SelectedEmail"]/option[' + randomSubject + ']')).click();
    browser.sleep(3000);   
}

this.writingMessage = function() {
    console.log("Contact: Writing a message");
    contact.messageField.sendKeys(contact.message);
}

this.captchaValidation = function() {
    console.log("Contact: Validating i am not a robot");
    contact.iamnotarobotCheckbox.click();

}

this.sendMessage = function() {
    console.log("Contact: Sending message");
    contact.sendButton.click();
}

this.verifySuccessMessage = function() {
    contact.thankyouMessage.getText().then(function (displayedMessage) {
        console.log("");
        expect(displayedMessage).toBe(thankyouMessage);
    });
}

}

module.exports = new Contact();
module.exports = function(){
    this.dropdownBrand = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[1]/div/app-dropdown/label/span[2]/select"));
    this.dropdownModel = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[2]/div/app-dropdown/label/span[2]/select"));
    this.dropdownPrice = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[3]/div/app-dropdown/label/span[2]/select"));
    
    this.fifthBrandInDropdown = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[1]/div/app-dropdown/label/span[2]/select/option[2]"));
    this.firstModelInDropdown = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[2]/div/app-dropdown/label/span[2]/select/option[2]"));
    this.firstPriceInDropdown = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[3]/div/app-dropdown/label/span[2]/select/option[2]"));
    
    this.btnShowSelection = element(by.xpath("//a[@class='button button--fluid']"));
    this.resultAmount = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/header/h3/span"));
    
    this.priceLabelPosition = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div/a/article/div/span[2]/span[2]/span[1]"));
    this.priceLabel = element(by.xpath("//span[@class='carTeaser__price'][contains(text(),'Verkocht')]"));
    
    this.resultGlobal = "";
    
    this.checkBoxCarBrand = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[1]/div[2]/div/div[1]/div/app-checkbox/div/label/span[1]/input"));
    this.checkboxCarModel = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[2]/div[2]/div/div[1]/div/app-checkbox/div/label/span[1]/input"));
    this.checkBoxPrice = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[3]/div[2]/div/div[3]/div/app-checkbox/div/label/span[1]/input"));   
}
module.exports = function() {

    this.totalCarsForSale = element(by.xpath('/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[2]/span[1]'));

    var carTeaserPrice = element(by.xpath('/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[3]/a/article/div/span[2]/span[2]/span[1]'));
    var carTeaserPriceGlobal;
    //  var banner = element(by.xpath("//h3[contains(text(),'Verkocht')]"));
    var firstCar = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[2]/span[1]"));

    this.carNameOverview = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/div"));
    this.carNameDetail = element(by.xpath("//h1[@id='model_title']"));

    this.fuelTypeOverview = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[1]/span[2]"));
    this.fuelTypeDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[1]/span[2]"));

    this.constructionYearOverview = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[2]/span[2]"));
    this.constructionYearDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[2]/span[2]"));

    this.mileageOverview = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[3]/span[2]"));
    this.mileageDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[3]/span[2]"));

    this.transmissionOverview = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[4]/span[2]"));
    this.transmissionDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[4]/span[2]"));

    this.btnFinancialSection = element(by.xpath("//h3[@onclick='financeClass.init()']"));

    this.controlPriceLeft = element(by.id("AdvanceMinLabel"));
    this.controlPriceRight = element(by.id("AdvanceMaxLabel"));

    this.referencePrice = element(by.xpath("//output[@class='input__flag']"));
    this.referencePriceGlobal;

    this.period = element(by.id("Period"));
    this.periodGlobal;

    this.jkp = element(by.id("jkp"));
    this.jkpGlobal;

    this.sliderBar = element(by.xpath("//input[@type='range']"));
    
    this.checkboxResidualValue = element(by.xpath("//*[@id='carDetailAside']/div[1]/section[2]/div/div/div/div[2]/label/span[2]"));
    this.checkboxResidualValueLabel = element(by.xpath("//*[@id='carDetailAside']/div[1]/section[2]/div/div/div/div[2]/label"));
    this.monthlyPaymentWithResidualValue = element(by.xpath("//*[@id='MonthPriceCarFinance']"));
    

}
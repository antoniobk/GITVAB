module.exports = function() {
    this.btnAutomaat = element(by.xpath("//span[@class='categorySearch__label'][contains(text(),'Automaat')]"));
    this.carFilterResultAmount = element(by.xpath("//span[@class='carFilterResult__amount']"));
    this.selectedCheckbox = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[4]/div[2]/div/div[1]/div/app-checkbox/div/label/span[1]/input"));
}

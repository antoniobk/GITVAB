module.exports = function() {
    this.btnVolledigAanbod = element(by.xpath("//a[@class='button button--fluid']"));
    this. acceptCookieBtn = element(by.xpath("/html/body/div/div[2]/div[4]/a[2]"));
    this.EC = protractor.ExpectedConditions;
}
var navigation = require('../pageObjects/navigation.js');
var filterCategorySearch = require('../pageObjects/filterCategorySearch.js');


describe('SecondHandCarsCategorySearch', function () {
    it('SecondHandCarsQuickSearch: Open browser, navigate to homepage', function () {
        console.log("SecondHandCarsQuickSearch: Navigeren naar tweedehands pagina");
        browser.sleep(5000);
        browser.waitForAngularEnabled(false);
        navigation.get();
        browser.sleep(5000);
    });

    it('SecondHandCarsQuickSearch: Accepting cookies', function () {
        console.log("Accepting cookies")
        navigation.acceptCookies();
    });

    it('SecondHandCarsCategorySearch: Clicking on a category', function () {
        console.log("SecondHandCarsCategorySearch: Clicking on a category")
        filterCategorySearch.clickOnCategory()
    });

    it('SecondHandCarsCategorySearch: Validating results', function () {
        console.log("SecondHandCarsCategorySearch: Validating if result is bigger than zero")
        filterCategorySearch.validateResultsBiggerThanZero();
    });

    it('Verifying if checkbox is selected: ', function () {
        console.log("SecondHandCarsCategorySearch: Verifying if checkbox is selected");
        filterCategorySearch.validateCheckBoxSelected();
    });

});
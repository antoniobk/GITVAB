var filterQuickSearch = require('../pageObjects/filterQuickSearch.js');
var navigation = require('../pageObjects/navigation.js');


describe('secondHandCarsQuickSearch', function () {
  it('SecondHandCarsQuickSearch: Open browser, navigate to homepage', function () {
    console.log("SecondHandCarsQuickSearch: Navigeren naar tweedehands pagina");
    browser.sleep(5000);
    navigation.get();
    browser.sleep(5000);
  });

  it('SecondHandCarsQuickSearch: Accepting cookies', function () {
    console.log("Accepting cookies")
    navigation.acceptCookies();
  });

  it('SecondHandCarsQuickSearch: Quick search', function () {
    filterQuickSearch.quickSearchCar()
  });

  it('SecondHandCarsQuickSearch: Getting result', function () {
    filterQuickSearch.getResultAmount();
  });

  it('SecondHandCarsQuickSearch: Verify if checkbox is selected', function () {
    filterQuickSearch.verifyCheckBoxSelected();
  });

  it('SecondHandCarsQuickSearch: Validate if the car is sold', function () {
    filterQuickSearch.validateCarSold();
  });

});
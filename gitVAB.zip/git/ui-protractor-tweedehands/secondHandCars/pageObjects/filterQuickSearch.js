var filterfilterQuickSearchObjects = require('../objectDefinitions/filterQuickSearchObjects')
var filterQuickSearch = function () {

var filterQuickSearchObject = new filterfilterQuickSearchObjects();

    this.quickSearchCar = function () {
        console.log("FilterQuickSearch: Selecting a car using the quick search");
        filterQuickSearchObject.dropdownBrand.click();
        browser.sleep(1000);
        filterQuickSearchObject.fifthBrandInDropdown.click();
        browser.sleep(1000);
        filterQuickSearchObject.dropdownModel.click();
        browser.sleep(1000);
        filterQuickSearchObject.firstModelInDropdown.click();
        browser.sleep(1000);
        filterQuickSearchObject.dropdownPrice.click();
        browser.sleep(1000);
        filterQuickSearchObject.firstPriceInDropdown.click();
        browser.sleep(1000);
        filterQuickSearchObject.btnShowSelection.click();
        browser.sleep(5000);
    }
    this.getResultAmount = function () {
        filterQuickSearchObject.resultAmount.getText().then(function (RS) {
            expect(RS).toBeGreaterThan(0);
            console.log("FilterQuickSearch: Total of result: " + RS);
            resultGlobal = RS
        });
    }
    this.verifyCheckBoxSelected = function () {
        console.log("FilterQuickSearch: Verifying if car brand checkbox is selected..");
        expect(filterQuickSearchObject.checkBoxCarBrand.isSelected()).toBe(true);
        console.log("FilterQuickSearch: Car model checkbox is selected");

        console.log("FilterQuickSearch: Verifying if car model checkbox is selected..")
        expect(filterQuickSearchObject.checkboxCarModel.isSelected()).toBe(true);

        console.log("FilterQuickSearch: Verifying if price checkbox is selected..");
        expect(filterQuickSearchObject.checkBoxPrice.isSelected()).toBe(true);
    }
    this.validateCarSold = function () {
        filterQuickSearchObject.priceLabelPosition.getText().then(function (PL) {

            if (resultGlobal == 1 && PL == "Verkocht") {
                console.log("FilterQuickSearch: There is Only one car and the car is sold, stopping test.");
                process.exit();
            }
            else {
                console.log("FilterQuickSearch: Car is not sold, car price is: " + PL + "Clicking on first car..")
                filterQuickSearchObject.priceLabelPosition.click();
            }
        });
    }
};
module.exports = new filterQuickSearch();
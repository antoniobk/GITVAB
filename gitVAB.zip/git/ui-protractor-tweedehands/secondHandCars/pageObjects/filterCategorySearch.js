var filterCategorySearchObjects = require('../objectDefinitions/filterCategorySearchObjects.js');
var filterCategorySearch = function () {

var filterCategorySearchObject = new filterCategorySearchObjects();

    this.clickOnCategory = function () {
        filterCategorySearchObject.btnAutomaat.click();
        browser.sleep(5000);
    }
    this.validateResultsBiggerThanZero = function () {
        browser.waitForAngularEnabled(false);
        filterCategorySearchObject.carFilterResultAmount.getText().then(function (totalResult) {
            console.log("FilterCategorySearch: expected total results: " + " >=1" + ", actual value: " + totalResult);
            expect(totalResult).toBeGreaterThan(0);

            if (totalResult >= 1) {
                console.log("FilterCategorySearch: results OK, continuing test.. ");
            }
            else {
                console.log("FilterCategorySearch: No results, stopping test.");
                process.exit();
            }
        });
    }

    this.validateCheckBoxSelected = function () {
        console.log("FilterCategorySearch: Verifying if checkbox is selected..");
        expect(filterCategorySearchObject.selectedCheckbox.isSelected()).toBe(true);
    }

}
module.exports = new filterCategorySearch();
var ProductObjects = require('../objectDefinitions/productObjects.js');
var Product = function () {
    var carNameGlobal;
    var fuelTypeGlobal;
    var constructionYearGlobal;
    var mileageGlobal;
    var transmissionGlobal;
    var totalCarsForSaleGlobal;

    var product = new ProductObjects();

    this.getCarName = async function () {
        console.log("Product: getCarName");
        carNameGlobal = await product.carNameOverview.getText();
    }

    this.getFuelType = async function () {
        console.log("Product: getFuelType");
        fuelTypeGlobal = await product.fuelTypeOverview.getText();
    }

    this.getConstructionYear = async function () {
        console.log("Product: getConstructionYear");
        constructionYearGlobal = await product.constructionYearOverview.getText();
    }

    this.getMileage = async function () {
        console.log("Product: getMileage");
        mileageGlobal = await product.mileageOverview.getText();
    }

    this.getTransmission = async function () {
        console.log("Product: getTransmission");
        transmissionGlobal = await product.transmissionOverview.getText();
    }

    this.getTotalCarsForSale = async function () {
        console.log("Product: getTotalCarsForSale");
        /* Antonio: Code te herzien. Je neemt hier enkel het eerste element en je telt niet alle elementen*/
    }

    this.checkCarStatus = function () {
        console.log("Product: checkCarStatus");
        var isVerkocht = false;

        console.log("checkCarStatus: Get total cars for sale");
        this.getTotalCarsForSale();

        console.log("checkCarStatus: Loop over cars");
        for (let i = 1; i < 4; i++) {
            console.log("checkCarStatus: Check car " + i);
            element = element(by.xpath('/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[' + i + ']/a/article/div/span[2]/span[2]/span[1]'));
            element.getText().then(function (textValue) {
                if (textValue == "Verkocht") {
                    console.log("checkCarStatus: Car is sold");
                    isVerkocht = true;
                }
            });
            if (!isVerkocht) {
                console.log("checkCarStatus: Car is not sold, test can continue");
                element.click();
                break;
            }
        }
    }

    this.validateCarNameDetail = async function () {
        console.log("Product: validateCarNameDetail");
        browser.waitForAngularEnabled(false);
        product.carNameDetail.getText().then(function (actualValue) {
            console.log("validateCarNameDetail: Car name expected value: " + carNameGlobal + ", actual value: " + actualValue);
            expect(carNameGlobal).toContain(actualValue);
        });
    }

    this.validatefuelTypeDetail = function () {
        console.log("Product: validatefuelTypeDetail");
        product.fuelTypeDetail.getText().then(function (actualValue) {
            console.log("validatefuelTypeDetail: Fuel Type expected value: " + fuelTypeGlobal + ", actual value: " + actualValue)
            expect(actualValue).toBe(fuelTypeGlobal);
        });
    }

    this.validateConstructionYearDetail = function () {
        console.log("Product: validateConstructionYearDetail");
        product.constructionYearDetail.getText().then(function (actualValue) {
            actualYear = actualValue.slice(5);
            console.log("validateConstructionYearDetail: Construction year expected value: " + constructionYearGlobal + ", actual value: " + actualYear);
            expect(actualYear).toBe(constructionYearGlobal);
        });
    }

    this.validateMileageDetail = function () {
        console.log("Product: validateMileageDetail");
        product.mileageDetail.getText().then(function (actualValue) {
            console.log("validateMileageDetail: Mileage expected value: " + mileageGlobal + ", actual value: " + actualValue);
            var mileageFormatted = mileageGlobal.toString().replace(".", " ");
            expect(actualValue).toBe(mileageFormatted);
        });
    }

    this.validateTansmissionDetail = function () {
        console.log("Product: validateTansmissionDetail");
        var regexCheckForHandGeschakeld = /[A-Z].*\d|\d.*[A-Z]/;


        product.transmissionDetail.getText().then(function (actualValue) {
            console.log("validateTansmissionDetail: Transmission expected value: " + transmissionGlobal + ", actual value: " + actualValue);


            if (transmissionGlobal == "Handgeschakeld") {
                expect(actualValue).toMatch(regexCheckForHandGeschakeld)

            }

            else {
                expect(actualValue).toBe("Automatisch"); //toBE (transmissionGlobal)

            }


        });
    }

    this.openFinancialSection = function () {
        console.log("Product: openFinancialSection");
        product.btnFinancialSection.click();
        browser.sleep(1000);
    }

    /* @TODO antonio: Refactor codenamings, .. from here on, according to upper code */

    this.getReferencePrice = function () {
        console.log("Product: getReferencePrice");
        product.referencePrice.getText().then(function (RP) {
            console.log("Product: " + "Reference price: " + RP);
            referencePrice = RP;
            referencePriceInt = parseInt(referencePrice)
        });
    }

    this.getPriceLeft = function () {
        console.log("Product: getPriceLeft");
        product.controlPriceLeft.getText().then(function (CPL) {
            console.log("Product: Price left: " + CPL);
            CPL = CPL;
            expect(CPL).toBeLessThan(referencePrice)

        });
    }

    this.getPriceRight = function () {
        console.log("Product: getPriceRight");
        product.controlPriceRight.getText().then(function (CPR) {
            console.log("Product: Price right: " + CPR);
            CPR = CPR;
            expect(CPR).toBeGreaterThan(referencePriceInt);
        });
    }

    this.getPeriod = function () {
        console.log("Product: getPeriod");
        product.period.getText().then(function (P) {
            console.log("Product: Current period: " + P + " months");
            period = P;
        });

    }

    this.getJkp = function () {
        console.log("Product: getJkp");
        product.jkp.getText().then(function (JKP) {
            console.log("Product: Current JKP: " + JKP + " %");
            jkp = JKP;
        });
    }

    this.getMonthlyPaymentWithResidualValue = function () {
        console.log("Product: getMonthlyPaymentWithResidualValue");

        WithresidualValue = product.monthlyPaymentWithResidualValue
        WithresidualValue.getText().then(function (MPWRV) {
            console.log("Product: Getting monthly payment that includes residual value, " + "Value: " + MPWRV);
            WithresidualValue = MPWRV

        });
    }

    this.verifyCheckboxResidualValueIsPresent = function () {
        console.log("Product: Verify if checkbox residual value is present");
        var withoutResidualValue;
        product.checkboxResidualValue.isPresent().then(function (elm) {
            if (elm) {
                console.log("element is present")
                browser.sleep(2000)
                console.log("Product: Deselectig checkbox residual value")
                product.checkboxResidualValueLabel.click();

                withoutResidualValue = product.monthlyPaymentWithResidualValue

                console.log("Product Getting monthly payment without residual value:");
                withoutResidualValue.getText().then(function (MPWIRV) {
                    withoutResidualValue = MPWIRV
                    console.log("Product: payment with residual value: " + WithresidualValue)
                    console.log("Product: payment without residual value: " + withoutResidualValue)
                    expect(withoutResidualValue).toBeGreaterThan(WithresidualValue);
                });
            }
            else {
                console.log("element is not present")
            }
        });
    }

    this.validatePeriod = function () {
        console.log("Product: validatePeriod");
        product.period.getText().then(function (P2) {
            console.log("Product: Period after change " + P2 + " months");
            expect(P2).toEqual(period);
        });

    }

    this.validateJkp = function () {
        console.log("Product: validateJkp");
        product.jkp.getText().then(function (JKP2) {
            console.log("Product: JKP after change: " + JKP2 + " %");
            expect(JKP2).toEqual(jkp);
        });
    }
}
module.exports = new Product();

var navigationObjects = require('../objectDefinitions/navigationObjects.js')
var Navigation = function () {

var navigationObject = new navigationObjects();

    this.get = function () {
		console.log("Navigation: get");
        browser.get("https://acc.vab.be/nl/auto/tweedehandswagens");
        browser.wait(navigationObject.EC.visibilityOf(navigationObject.btnVolledigAanbod), 30000, "Timeout of VisibilityOf: Homepage secondhandcars");
        browser.sleep(5000);
    };

    this.acceptCookies = function () {
		console.log("Navigation: acceptCookies");
        navigationObject.acceptCookieBtn.click();
        browser.sleep(5000);
    };

    this.bekijkVolledigAanbod = function () {
		console.log("Navigation: bekijkVolledigAanbod");
        navigationObject.btnVolledigAanbod.click();
        browser.sleep(5000);
    };
};
module.exports = new Navigation();
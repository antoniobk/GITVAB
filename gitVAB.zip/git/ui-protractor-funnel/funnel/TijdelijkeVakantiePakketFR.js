var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
var tariffFunctions = require('./VABCommon/tariffFunctions.js');
var componentFunctions = require('./VABCommon/componentFunctions.js');

describe("TijdelijkeVakantiePakketFR: TijdelijkeVakantiePakketFR", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;
    
    var totalDays=9;
    var totalMonths=1;
    var totalTravelPrice=3000;
    var maxPersons=9;
    var totalPersons=2;
    var additionalPersons=2;
    var maxVehicles=5;
    var totalVehicles=2;
    var additionalVehicles=2;

    it('TijdelijkeVakantiePakketFR: Open browser & accepteer cookies', function () {
        console.log("TijdelijkeVakantiePakketFR: Open browser & accepteer cookies");
        browser.get(applicationURL + '/fr/assistance/assistance-voyage/assistance-voyage-temporaire/formule-vacances-avec-bagages');
        browser.sleep(2000);
        common.cookie.click();
        browser.sleep(2000);
        browser.waitForAngularEnabled(false);
    });

    it("TijdelijkeVakantiePakketFR: Valideer prijs", function () {
        console.log("TijdelijkeVakantiePakketFR: Valideer prijs");
        var priceHeader = element(by.className("vab__calculator__form__price vab__heading--1"));
        browser.wait(EC.visibilityOf(priceHeader), 50000, "Timeout of VisibilityOf: HomePage TijdelijkeVakantiePakketFR");

        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPrice) {
            expect(defaultPrice).toBe('€ 0');
        });
    });

    it('TijdelijkeVakantiePakketFR: Vul datums in', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul datums in");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/app-text-option/div/label/div[2]/app-text-input/div/div/input')).sendKeys(totalTravelPrice);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
        browser.sleep(2000);
    });

    it('TijdelijkeVakantiePakketFR: Vul start datum in', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul start datum in");
        startDate = dateFunctions.addTotalDays(1);
        console.log('startdate: ' + startDate);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
        browser.sleep(2000);
    });

    it
    it('TijdelijkeVakantiePakketFR: Vul eind datum in', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul eind datum in");
        endDate = dateFunctions.addTotalDaysReferenceDate(startDate,totalDays);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);

        // Wijzig focus door validaties
        element(by.className('vab__calculator__form__theHeading')).click();
        browser.sleep(2000);
    });


    it('TijdelijkeVakantiePakketFR: Voeg personen toe', function () {
        console.log("TijdelijkeVakantiePakketFR: Voeg personen toe");
        for (let i = 2; i <= totalPersons; i++) {
            console.log("TijdelijkeVakantiePakketFR: Voeg persoon toe");
            componentFunctions.addPerson();

            console.log("TijdelijkeVakantiePakketFR: Bereken prijs");
            expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,i,0);     
            
            console.log("TijdelijkeVakantiePakketFR: Valideer prijs");
            var elementPrice = element(by.className("vab__calculator__form__price vab__heading--1"));               
            componentFunctions.validatePrice(elementPrice,expectedPrice);
            
        }  
    });


    it('TijdelijkeVakantiePakketFR: Voeg voertuigen toe', function () {
        console.log("TijdelijkeVakantiePakketFR: Voeg voertuigen toe");
		for (let i = 1; i <= totalVehicles; i++) {
            console.log("TijdelijkeVakantiePakketFR: Voeg voertuig toe");
            componentFunctions.addVehicle();
            console.log("TijdelijkeVakantiePakketFR: Bereken prijs");
            expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,totalPersons,i);
            
            console.log("TijdelijkeVakantiePakketFR: Valideer prijs");
            var elementPrice = element(by.className("vab__calculator__form__price vab__heading--1"));
            componentFunctions.validatePrice(elementPrice,expectedPrice);      
		}
    });


    it('TijdelijkeVakantiePakketFR: Klik op Bestel online', function () {
        console.log("TijdelijkeVakantiePakketFR: Klik op Bestel online");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
        browser.sleep(3000);
    });


    it('TijdelijkeVakantiePakketFR: Valideer prijs', function () {
        console.log("TijdelijkeVakantiePakketFR: Valideer prijs");
		elementPrice = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span'));
        componentFunctions.validatePrice(elementPrice,expectedPrice);
    });

    it("TijdelijkeVakantiePakketFR: Valideer start datum", function () {
        console.log("TijdelijkeVakantiePakketFR: Valideer start datum");
        var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
        console.log("Start datum:" + startDate);
        expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
    });

    it("TijdelijkeVakantiePakketFR: Valideer eind datum", function () {
        console.log("TijdelijkeVakantiePakketFR: Valideer eind datum");
        var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
        console.log("Eind Datum: " + endDate);
        expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
    });


    it('TijdelijkeVakantiePakketFR: Vul gegevens in personen', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul gegevens in personen");
        for (let i = 1; i <= totalPersons; i++) {
            componentFunctions.fillPersonInformation(i);
        }
    });

    it('TijdelijkeVakantiePakketFR: Voeg medereizigers toe', function () {
        console.log("TijdelijkeVakantiePakketFR: Voeg medereizigers toe");
        componentFunctions.fillAdditionalPersons(additionalPersons,totalPersons,maxPersons,totalTravelPrice,totalDays,totalMonths,totalVehicles);
    });
  
    it('TijdelijkeVakantiePakketFR: Vul gegevens in voertuigen', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul gegevens in voertuigen");
        for (let i = 1; i <= totalVehicles; i++) {
            componentFunctions.fillVehicleInformation(i);
        }
    });

    it('TijdelijkeVakantiePakketFR: Voeg extra voertuigen toe', function () {
        console.log("TijdelijkeVakantiePakketFR: Voeg extra voertuigen toe");        
        totalPersons=totalPersons+additionalPersons;
        componentFunctions.fillAdditionalVehicles(additionalVehicles,totalVehicles,maxVehicles,totalTravelPrice,totalDays,totalMonths,totalPersons);
    });

    it('TijdelijkeVakantiePakketFR: Klik op volgende knop', function () {
        console.log("TijdelijkeVakantiePakkentNL: Klik op volgende knop");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
        browser.sleep(3000);
    });

    it('TijdelijkeVakantiePakketFR: Vul gegevens in', function () {
		console.log("TijdelijkeVakantiePakketFR: Vul gegevens in");
        componentFunctions.fillPersonalData();

    });

    it('TijdelijkeVakantiePakketFR: Klik checkbox algemene voorwaarden', function () {
        console.log("TijdelijkeVakantiePakketFR: Klik checkbox algemene voorwaarden");
        common.checkbox.click();
    });

    it('TijdelijkeVakantiePakketFR: Klik op volgende knop', function () {
        console.log("TijdelijkeVakantiePakketFR: Klik op volgende knop");
        browser.sleep(2000);
        common.nextButton.click();
        browser.sleep(2000);
    });

    it('TijdelijkeVakantiePakketFR: Vul behoefteanalyse pagina in', function () {
        console.log("TijdelijkeVakantiePakketFR: Vul behoefteanalyse pagina in");
        componentFunctions.fillBehoefteAnalyse();
    });

    it('TijdelijkeVakantiePakketFR: Klik op toon resultaat', function () {
        console.log("TijdelijkeVakantiePakketFR: Klik op toon resultaat");
        element(by.id('submitBtn')).click();
        browser.sleep(2000);
    });

    it('TijdelijkeVakantiePakketFR: Valideer resultaat tekst', function () {
        console.log("TijdelijkeVakantiePakketFR: Valideer resultaat tekst");
        element(by.xpath('//*[@id="scrollToHere"]')).getText().then(function (text) {
            expect(text).toBe("Le produit que vous avez sélectionné répond à vos besoins. Cliquez sur ‘suivant’ pour continuer avec ce produit.");
        });
    });

    it('TijdelijkeVakantiePakketFR: Klik op volgende knop', function () {
        console.log("TijdelijkeVakantiePakketFR: Klik op volgende knop");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
        browser.sleep(4000);
    });

    if (common.payment) {
        it('Betaalstap selecteer MasterCard', function () {
            paymentFunctions.masterCardPayment();
        });
    };
});


var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("TijdelijkeReisbijstandBagageFR: Tijdelijke reisverzekering: Bagage", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;
	var vehiclePriceFormatted;

	it('TijdelijkeReisbijstandBagageFR: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Open browser & accepteer cookies");
		browser.get(applicationURL + '/fr/assistance/assistance-voyage/assistance-voyage-temporaire/assistance-voyage-avec-bagages');
		browser.sleep(3000);
		common.cookie.click();
		browser.sleep(2000);
		browser.waitForAngularEnabled(false);
	});

	it("TijdelijkeReisbijstandFR: Scroll naar calculator", function () {
        console.log("TijdelijkeReisbijstandNL: Scrollen naar calculator");
        browser.executeScript('window.scrollTo(0,500);');
        browser.sleep(2000);
    });

	it('TijdelijkeReisbijstandBagageFR: Valideer prijs ', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer prijs");
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 0');
        });        
		browser.sleep(1000);
	});

	it('TijdelijkeReisbijstandBagageFR: Voeg personen toe', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Voeg personen toe");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
	});

	it('TijdelijkeReisbijstandBagageFR: Voeg personen', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Voeg personen toe");
		var personPrice = 67.5;
		var addPriceVehicle = 36;

		for (i = 0; i < 2; i++) {
			element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
			browser.sleep(2000);

			element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
				console.log('TijdelijkeReisbijstandBagageFR: Valideer prijs');
				personPrice = personPrice + addPriceVehicle;
				vehiclePriceFormatted = personPrice.toString().replace(".", ",");
				expect(defaultPricing).toBe('€ ' + vehiclePriceFormatted);

				console.log('TijdelijkeReisbijstandBagageFR: Vehicle prijs = ' + personPrice);
			});
		}
	});



	it('TijdelijkeReisbijstandBagageFR: Vul start datum in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul start datum in");
		startDate = dateFunctions.addTotalDays(1);
		console.log('TijdelijkeReisbijstandBagageNL: startdate: ' + startDate);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageFR: Vul eind datum in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul eind datum in");
		endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 8);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).click();
		browser.sleep(2000);
	});


	it('TijdelijkeReisbijstandBagageFR: Klik op bestel online', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Klik op bestel online');
		browser.executeScript('window.scrollTo(0,1000);');
		browser.sleep(2000);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Étape 1 sur 4 : Votre Assistance voyage avec bagages temporaire");
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ ' + vehiclePriceFormatted)
		});
	});

	it("TijdelijkeReisbijstandBagageFR: Valideer start datum", function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer start datum");
		var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
		console.log("Start datum:" + startDate);
		expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
	});

	it("TijdelijkeReisbijstandBagageFR: Valideer eind datum", function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer eind datum");
		var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
		console.log("Eind Datum: " + endDate);
		expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
	});

	it('TijdelijkeReisbijstandBagageFR: Vul gegevens persoon 1 in', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Vul gegevens personen in');
	
			console.log("TijdelijkeReisbijstandBagageFR: Vul gegevens in persoon 1 in");
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[1]/div/div[1]/label[1]/input')).sendKeys(common.userFirstName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[1]/div/div[1]/label[2]/input')).sendKeys(common.userLastName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

			// Wijzig focus door validaties
			element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
			browser.sleep(5000);
		
	});

	it('TijdelijkeReisbijstandBagageFR: Voeg medereiziger toe', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Voeg medereiziger toe");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeReisbijstandBagageFR: Vul gegevens persoon 3 in', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Vul gegevens persoon 3 in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[1]/input')).sendKeys(common.userFirstName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[2]/input')).sendKeys(common.userLastName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
		// Wijzig focus door validaties
		element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ 171')
		});
	});

	it('TijdelijkeReisbijstandBagageFR: Vul nummerplaten', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Vul nummerplaten');
		for (i = 1; i <= 3; i++) {
			console.log("TijdelijkeReisbijstandBagageFR: Vul nummerplaat " + i + " in");
			let rdnNummerplaat = Math.random().toString(36).substr(2, 6);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[' + i + ']/div/div/label/input')).sendKeys(rdnNummerplaat);
			// Wijzig focus door validaties
			element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
			browser.sleep(5000);
		}
	});

	it('TijdelijkeReisbijstandBagageFR: Voeg een vierde voertuig toe', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Voeg een derde voertuig toe");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/a')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeReisbijstandBagageFR: vul nummerplaat voertuig vier in', function () {
		console.log("TijdelijkeReisbijstandBagageFR: vul nummerplaat voertuig drie in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[4]/div/div/label/input')).sendKeys("kyq8943")
		// Wijzig focus door validaties
		element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ 207')
		});
	});

	it('TijdelijkeReisbijstandBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
        browser.sleep(3000);        
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Étape 2 sur 4 : Données");
	});

	it('TijdelijkeReisbijstandBagageFR: Vul adres in', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Vul adres in");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
	});

	it('TijdelijkeReisbijstandBagageFR: Vul email in', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Vul email in");
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageFR: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Klik checkbox algemene voorwaarden");
		common.checkbox.click();
	});

	it('TijdelijkeReisbijstandBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Klik op volgende knop");
		browser.sleep(2000);
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Étape 3 sur 4 : Analyse des besoins");
	});

	it('TijdelijkeReisbijstandBagageFR: Vul behoefteanalyse pagina in', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Vul behoefteanalyse pagina in");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageFR: Klik op toon resultaat', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer resultaat tekst', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]')).getText().then(function (text) {
			expect(text).toBe(common.behoefteAnalyseTijdelijkeBagageFR);
		});
	});

	it('TijdelijkeReisbijstandBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageFR: Klik op volgende knop");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(4000);
	});

	it('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageFR: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Étape 4 sur 4 : Paiement");
	});

	if (common.payment) {
		it('TijdelijkeReisbijstandBagageFR: Betaalstap selecteer MasterCard', function () {
            console.log('TijdelijkeReisbijstandBagageFR: Betaalstap selecteer MasterCard');
			paymentFunctions.visaPayment();
		});
	};
});
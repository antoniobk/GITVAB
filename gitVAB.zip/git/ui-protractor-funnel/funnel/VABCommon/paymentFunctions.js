
var dateFunctions = require('./dateFunctions.js');
var PaymentFunctions = function () {
    var EC = protractor.ExpectedConditions;

    this.setPaymentData = function(){
        console.log('Paymentfunctions - setPaymentData');
        console.log('Paymentfunctions - Discount');
        this.voucherCode = 'VS9CTD';

        console.log('Paymentfunctions - Payment details VISA');
        this.futureYear = dateFunctions.getFutureYear(3);
        this.creditCardNumber = '4111111111111111';
        this.creditCardVerificationNumber = '123';
        this.paymentUserName = 'TESTVAB PAYMENTUSER';

        console.log('Paymentfunctions - Payment details MasterCard');
        this.futureYearMC = dateFunctions.getFutureYear(3);
        this.creditCardNumberMC = '5399999999999999';
        this.creditCardVerificationNumberMC = '123';
        this.paymentUserNameMC = 'TESTVAB PAYMENTUSER';

        console.log('Paymentfunctions - Payment details BC');
        this.cardHolder = 'VAB kaarthouder';
        this.creditCardNumberBC = '67030000000000003';
    }

    this.kbcPayment = function () {
        console.log('Paymentfunctions - kbcPayment');
        console.log('Paymentfunctions - Selecteer betaalmogelijkheid'); 

        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/label/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[1]/div/div[1]/div[2]/div/label/span[1]')).click();
        browser.sleep(4000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[2]/button/span')).click();
        browser.sleep(4000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        ele = element(by.xpath('//*[@id="ACS"]/h1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: KBC Online simulator");

        console.log('Paymentfunctions - Confirmeer betaling');
        element(by.xpath('//*[@id="btn_Accept"]')).click();
        browser.sleep(4000);
    };

    this.visaPayment = function () {
        console.log('Paymentfunctions - visaPayment');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();

        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form/ul[2]/li[2]/label/div/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form/ul[2]/li[2]/div/div/div/button')).click();
        browser.sleep(2000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        var ele = element(by.xpath('//*[@id="payment-zone"]/form/table/tbody/tr[1]/td[1]/small'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Betaal met");

        console.log("Paymentfunctions - Vul betaal gegevens in");
        element(by.id('Ecom_Payment_Card_Name')).sendKeys(this.paymentUserName);
        element(by.id('Ecom_Payment_Card_Number')).sendKeys(this.creditCardNumber);
        element(by.id('Ecom_Payment_Card_Verification')).sendKeys(this.creditCardVerificationNumber);
        element(by.id('Ecom_Payment_Card_ExpDate_Month')).sendKeys('11');
        element(by.id('Ecom_Payment_Card_ExpDate_Year')).sendKeys(this.futureYear);
        browser.sleep(2000);

        console.log('Paymentfunctions - Confirmeer betaling');
        element(by.id('submit3')).click();
        browser.sleep(2000);
    };

    this.bankContactPayment = function () {
        console.log('Paymentfunctions - bankContactPayment');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();

        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");
        browser.sleep(4000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/label/span[1]')).click();
        browser.sleep(2000);
        
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[1]/div/div[1]/div[1]/div/label/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[2]/button/span')).click();
        browser.sleep(5000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        console.log('Paymentfunctions - Vul betaal gegevens in');
        element(by.id('Ecom_Payment_Card_Name')).sendKeys(this.cardHolder);
        browser.sleep(2000);
        element(by.id('Ecom_Payment_Card_Number')).sendKeys(this.creditCardNumberBC);
        browser.sleep(2000);
        element(by.id('Ecom_Payment_Card_ExpDate_Month')).sendKeys('11');
        browser.sleep(2000);
        element(by.id('Ecom_Payment_Card_ExpDate_Year')).sendKeys(this.futureYear);
        browser.sleep(2000);

        console.log('Paymentfunctions - Confirmeer betaling');
        element(by.xpath('//*[@id="btn_sendCardData"]')).click();
        browser.sleep(2000);

        element(by.xpath('//*[@id="Submit"]')).click();
        browser.sleep(2000);
    };

    this.masterCardPayment = function () {
        console.log('Paymentfunctions - masterCardPayment');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();

        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");
        browser.sleep(4000);

        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[3]/label/div/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[3]/div/div/div/button/span')).click();
        browser.sleep(2000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        var ele = element(by.xpath('//*[@id="payment-zone"]/form/table/tbody/tr[1]/td[1]/small'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Betaal met");

        console.log('Paymentfunctions - Vul betaal gegevens in');
        element(by.id('Ecom_Payment_Card_Name')).sendKeys(this.paymentUserNameMC);
        element(by.id('Ecom_Payment_Card_Number')).sendKeys(this.creditCardNumberMC);
        element(by.id('Ecom_Payment_Card_Verification')).sendKeys(this.creditCardVerificationNumberMC);
        element(by.id('Ecom_Payment_Card_ExpDate_Month')).sendKeys('11');
        element(by.id('Ecom_Payment_Card_ExpDate_Year')).sendKeys(this.futureYearMC);
        browser.sleep(2000);

        console.log('Paymentfunctions - Confirmeer betaling');
        element(by.id('submit3')).click();
        browser.sleep(2000);
    };


    this.cbcPayment = function () {
        console.log('Paymentfunctions - cbcPayment');
        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");        
        browser.sleep(4000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/label/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[1]/div/div[1]/div[3]/div/label/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div[1]/div[1]/div/div/div/form/ul[2]/li[1]/div/div/div[2]/button/span')).click();
        browser.sleep(2000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        var ele = element(by.xpath('//*[@id="ACS"]/h1'));
        browser.wait(EC.visibilityOf(ele), 10000, "Timeout of VisibilityOf: KBC Online simulator");

        console.log("Paymentfunctions - Confirmeer betaling");
        element(by.xpath('//*[@id="btn_Accept"]')).click();
        browser.sleep(2000);

    };

    this.masterCardFiets = function () {
        console.log('Paymentfunctions - masterCardFiets');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();

        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");
        browser.sleep(4000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[2]/div/app-paymentradiobuttonlist/ul/li[3]')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[2]/div/app-paymentradiobuttonlist/ul/li[3]/app-paymentoption/div/div/div/button/span')).click();
        browser.sleep(5000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        var ele = element(by.xpath('//*[@id="payment-zone"]/form/table/tbody/tr[1]/td[1]/small'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Betaal met");

        console.log('Paymentfunctions - Vul betaal gegevens in');
        element(by.id('Ecom_Payment_Card_Name')).sendKeys(this.paymentUserNameMC);
        element(by.id('Ecom_Payment_Card_Number')).sendKeys(this.creditCardNumberMC);
        element(by.id('Ecom_Payment_Card_Verification')).sendKeys(this.creditCardVerificationNumberMC);
        element(by.id('Ecom_Payment_Card_ExpDate_Month')).sendKeys('11');
        element(by.id('Ecom_Payment_Card_ExpDate_Year')).sendKeys(this.futureYearMC);
        browser.sleep(2000);

        console.log("Paymentfunctions - Confirmeer betaling");
        element(by.id('submit3')).click();
        browser.sleep(2000);

    };

    this.visaPaymentFiets = function () {
        console.log('Paymentfunctions - visaPaymentFiets');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();
        
        console.log("Paymentfunctions - Selecteer betaalmogelijkheid");
        browser.sleep(5000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[2]/div/app-paymentradiobuttonlist/ul/li[2]')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[2]/div/app-paymentradiobuttonlist/ul/li[2]/app-paymentoption/div/div/div/button')).click();
        browser.sleep(6000);

        console.log('Paymentfunctions - Ga naar de Ogone betaal pagina');
        var ele = element(by.xpath('//*[@id="payment-zone"]/form/table/tbody/tr[1]/td[1]/small'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Betaal met");

        console.log("Paymentfunctions - Vul betaal gegevens in");
        element(by.id('Ecom_Payment_Card_Name')).sendKeys(this.paymentUserName);
        element(by.id('Ecom_Payment_Card_Number')).sendKeys(this.creditCardNumber);
        element(by.id('Ecom_Payment_Card_Verification')).sendKeys(this.creditCardVerificationNumber);

        element(by.id('Ecom_Payment_Card_ExpDate_Month')).sendKeys('11');
        element(by.id('Ecom_Payment_Card_ExpDate_Year')).sendKeys(this.futureYear);
        browser.sleep(2000);

        console.log('Paymentfunctions - Confirmeer betaling');
        element(by.id('submit3')).click();
        browser.sleep(2000);
    };

    this.setVoucherCode = function(confirmVoucher){
        console.log('Paymentfunctions - setVoucherCode');
        console.log('Paymentfunctions - Set parameters payment');
        this.setPaymentData();
    
        console.log('Paymentfunctions - Klik op vouchercode');
		element(by.className('vab__fs--4 vab__options__list__trigger vab__link--directional-dnwd--primair-2 vab__layout--xs-pv-small vab__layout--xs-mh-xsmall vab__layout--s-mh-small _accordion__trigger _voucher')).click();
        browser.sleep(2000);
        
        console.log('Paymentfunctions - Vul vouchercode in');
		element(by.id('VoucherCode')).sendKeys(this.voucherCode);
        browser.sleep(2000);
        
        console.log('Paymentfunctions - Confirmeer vouchercode in');
		element(by.xpath('//*[@id="voucherSubmit"]')).click();
        browser.sleep(2000);
        
        if (confirmVoucher){
            element(by.xpath('//*[@id="voucherYes"]')).click();
            browser.sleep(2000);
        }
    }
};
module.exports = new PaymentFunctions();
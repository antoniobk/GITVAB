var DateFunctions = function(){

	this.getFutureDate = function(startDay, addTotalMonths) {
		console.log ('Datefunctions - getFutureDate');
		//startDay = Dag van de maand
		//addTotalMonths = Aantal maanden dat er bij opgeteld moeten worden

		// Get current time
		var date = new Date();   
		date.setMonth(date.getMonth()+addTotalMonths);
		date.setDate(startDay);
	
		// Correctie omdat javascript vanaf 0 maanden telt
		var calculatedMonth=date.getMonth()+1;

		// Format		
		var formattedDate = this.getFormattedDate(date.getDate(),calculatedMonth,date.getFullYear(),'/');
		console.log ('Return = ' + formattedDate);

		return formattedDate;
	};

	this.addTotalDays = function(totalDays) {
		console.log ('Datefunctions - totalDays');
		//totalDays = Het aantal dagen dat er wordt opgeteld bij de dag van vandaag

		// Get current time
		var date = new Date();

		// Add totaldays
		date.setDate(date.getDate() + totalDays);

		// Correctie omdat javascript vanaf 0 maanden telt
		var calculatedMonth=date.getMonth()+1;

		// Format
		var formattedDate = this.getFormattedDate(date.getDate(),calculatedMonth,date.getFullYear(),'/');
		console.log ('Return = ' + formattedDate);
		
		return formattedDate;
	};
	
	this.addTotalDaysReferenceDate = function(referenceDate,totalDays) {
		console.log ('Datefunctions - addTotalDaysReferenceDate');
		//totalDays = Het aantal dagen dat er wordt opgeteld bij de dag van vandaag

		// Get current time, convert to USA time for counting days 
		var date = new Date(this.convertBelgiumToUsaDate(referenceDate,'/'));
		console.log ('Date = ' + date);

		// Add totaldays
		date.setDate(date.getDate() + totalDays);

		// Correctie omdat javascript vanaf 0 maanden telt
		var calculatedMonth=date.getMonth()+1;

		// Format
		var formattedDate = this.getFormattedDate(date.getDate(),calculatedMonth,date.getFullYear(),'/');
		console.log ('Return = ' + formattedDate);
		
		return formattedDate;
	};

	this.getFormattedDate = function(day, month, year, delimeter){
		console.log ('Datefunctions - getFormattedDate');
		// Format
		var formattedDate = day + delimeter + month + delimeter + year;
		console.log ('Return = ' + formattedDate);

		return formattedDate;
	};
	
	this.convertBelgiumToUsaDate = function(date, delimeter){
		console.log ('Datefunctions - convertBelgiumToUsaDate');
		console.log ('Date = ' + date);
		var splittedDate = date.split("/")

		// Format
		var formattedDate = splittedDate[1] + delimeter + splittedDate[0] + delimeter + splittedDate[2];
		console.log ('Return = ' + formattedDate);

		return formattedDate;
    };	
    
    this.getFutureYear = function(totalYears){
        console.log ('Datefunctions - getFutureYear add ' + totalYears + " years");
        var date = new Date(new Date()); 
        var year = date.getFullYear();
        var futureYear=year + totalYears;

		console.log ('Return = ' + futureYear);
        return futureYear;
    }
};

module.exports = new DateFunctions();
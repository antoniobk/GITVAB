var CommonFunctions = function () {

    this.getEnvironmentURL = function (environment) {
        console.log('CommonFunctions - setEnvironment: ' + environment);
        var environmentURL;

        switch(environment){
            case "acc":
                environmentURL="https://acc.vab.be";
                break;
            case "preprod":
                environmentURL="https://preprod.vab.be"
                break;
            default:
                console.log("No environmentURL can be set");
        }

        console.log(environmentURL);
        return environmentURL;
    };

    this.getEnvironmentReportsDirectory = function (environment) {
        console.log('CommonFunctions - setEnvironmentReportsDirectory: ' + environment);
        var reportsDirectory;

        switch(environment){
            case "acc":
                reportsDirectory="funnel/reports/xml/acc";
                break;
            case "preprod":
                reportsDirectory="funnel/reports/xml/preprod"
                break;
            default:
                console.log("No reportsDirectory can be set");
        }
        
        console.log(reportsDirectory);
        return reportsDirectory;
    };
};

module.exports = new CommonFunctions();
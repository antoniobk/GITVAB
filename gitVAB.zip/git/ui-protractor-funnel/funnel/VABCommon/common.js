module.exports = function(){
	
var commonFunctions = require('./commonFunctions.js');
var environment = browser.params.environment;
    
    // VAB Common
	this.applicationURL = commonFunctions.getEnvironmentURL(environment);	
    this.cookie =element(by.xpath(browser.params.cookie));	
    
	// Common variables
	this.userEmail = "cva@vab.be";
	this.userCity = "Zwijndrecht";
	this.userZipcode = "2070";
	this.userStreet = "Pastoor Coplaan";
	this.userHouseNumber = "100";
	this.userFirstName = "ABZ";
	this.userLastName = "TESTVAB-Last";
	this.userBirthDate = "29/02/1984";
    this.userValidIBAN = "BE19688479467929";

    //behoefteanalyses
    this.behoefteAnalyseTijdelijkeBagageFR="Sur base de vos réponses, nous vous recommandons le produit suivant : Formule vacances avec bagages temporaire seul\nJe souhaite examiner le produit que vous me recommandez.\nCliquez sur ‘suivant’ pour continuer.";
    this.befoefteAnalyseTijdelijkeBagageNL="Op basis van jouw antwoorden stellen we het volgende product voor: VAB-Vakantiepakket + Bagage single\nIk wil het product bekijken dat geadviseerd wordt\nKlik op volgende als je wil doorgaan met je huidig product.";
	
	// Motorbijstand & Pechbijstand
	this.licensePlateOne = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label/input'));
	this.licensePlateTwo = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label/input'));
	this.checkbox = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label/span[1]'));
	this.checkboxGeneralTerms = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[1]')); 
   // this.checkboxGeneralTerms = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]'));
	this.checkboxDirectDebit = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[2]/span[1]'));
	this.nextButton = element(by.className('vab__button__icon vab__icon--chevron-right'));
	
	// Persoonsgegevens velden: Stap 2 van 3: Gegevens
	this.firstName = element(by.id('PersonalDataViewModel_FirstName'));
	this.lastName = element(by.id('PersonalDataViewModel_LastName'));
	this.datepicker = element(by.id("PersonalDataViewModel_BirthdateText"));
	this.zipcode = element(by.id("PersonalDataViewModel_AddressViewModel_ZipCode"));
	this.city = element(by.id("PersonalDataViewModel_AddressViewModel_City"));
	this.street = element(by.id("PersonalDataViewModel_AddressViewModel_Street"));
	this.houseNumber = element(by.id("PersonalDataViewModel_AddressViewModel_Number"));
	this.email = element(by.id("PersonalDataViewModel_ContactDataViewModel_EmailAddress"));
	this.IBAN = element(by.id("PersonalDataViewModel_DirectDebitViewModel_IBAN"));
		
	// Get time
    var date = new Date(new Date()); 
	var month = date.getMonth() + 1;
	var year = date.getFullYear();
    
    // Environment specific texts
    switch(environment){
        case "acc":
        this.payment=true;
        this.pechbijstandTitelNL="VAB-Pechbijstand";
        this.pechbijstandTitelFR="En route sans nuage avec l’assistance VAB";
        break;
    case "preprod":
        this.payment=false;        
        this.pechbijstandTitelFR="En route sans nuage avec l’assistance VAB";
        this.pechbijstandTitelNL="Zorgeloos op weg met je VAB bijstand";
        break;
    default:
        console.log("No environmentURL can be set");
    }

    this.berekenPrijsTitelFR="Calculez le taux";
    this.fietsbijstandTitelNL="Stap 1 van 3: Jouw VAB-Fietsbijstand";
    this.behoefteAnalyseNL="Op basis van jouw antwoorden stellen we het volgende product voor: Tijdelijk vakantiepakket met bagage single";
    this.behoefteAnalyseTijdelijkeNL="Op basis van jouw antwoorden stellen we het volgende product voor: VAB-Vakantiepakket + Bagage single";
    this.behoefteAnalyseFR="Sur base de vos réponses, nous vous recommandons le produit suivant : VAB-Formule Multi famille";
    this.behoefteAnalyseFR="Sur base de vos réponses, nous vous recommandons le produit suivant : Formule Multi VAB famille";
    this.vakantiepakketTitelFR="Étape 1 sur 4 : Votre Formule Vacances VAB";
    this.multipakketTitelFR="Étape 1 sur 4 : Votre Formule Multi VAB";
    this.fietsverzekeringTitleFR="Étape 1 sur 4 : Votre Assurance Vélo VAB";
    this.reisbijstandTitleFR="Étape 1 sur 4 : Votre Assistance Voyage VAB";
    this.bijstandspakketTitelFR="Étape 1 sur 4 : Votre Formule Assistance VAB";
    this.tijdelijkeBagageTitelNL="Stap 1 van 4: Jouw VAB-Bagageverzekering";
    this.tijdelijkeBagageTitelFR="Étape 1 sur 4 : Votre Assurance Bagages VAB";
    this.tijdelijkeAnnulatieTitelNL="Stap 1 van 4: Jouw VAB-Annulatieverzekering"; 
}
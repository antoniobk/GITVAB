var Common = require('./VABcommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("Fietsverzekering: Buy a product", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('FietsverzekeringFR: Open browser & accepteer cookies', function () {
        console.log("FietsverzekeringFR: Open browser & accepteer cookies");
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/fiets/fietsverzekering');
        browser.sleep(4000);

        //TODO: Check if this is still necessary:
        //Fix is necessary for automatic play of movie on page
        //browser.actions().mouseMove(element(by.xpath('//*[@id="page-container"]/div/div/app-funnel-options/div[1]/div/ul/li/span'))).perform();
        //browser.sleep(2000);

        common.cookie.click();
        browser.sleep(2000);
        console.log('FietsverzekeringFR: Wijzig taal naar FR');
        browser.sleep(2000);
        element(by.xpath('//*[@id="1"]')).click();
        browser.sleep(4000);
        
        console.log('FietsverzekeringFR: Klik op taal FR');
        element(by.xpath('//*[@id="2"]')).click();
        browser.sleep(2000); 
    })

    it('FietsverzekeringFR: Vul prijs & aankoopdatum in', function () {
        console.log('FietsverzekeringFR: Vul prijs & aankoopdatum in');
        var ele = element(by.className('vab__calculator__form__theHeading'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Fietsverzekering homepage");

        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[3]/app-textinput/div/label/div[2]/div/div/input')).sendKeys('10000');
        browser.sleep(2000);

        console.log('FietsverzekeringFR: Vul aankoopdatum in');
        var purchaseDate = dateFunctions.getFutureDate(1, 0);
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[1]/app-dateinput/div/label/div[2]/app-material-datepicker/div/input')).sendKeys(purchaseDate);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[2]/app-radiobuttonlist/div/div[1]/div/div/label/span[1]')).click();
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Valideer prijs calculator', function () {
        console.log('FietsverzekeringFR: Valideer prijs calculator');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            // KP-73 tijdelijke aanpassing in afwachting van nauwkeurigere prijs door KLA 
            expect(updatedPricing).toBe('€ 382,01');
            // expect(updatedPricing).toBe('€ 416');  
            browser.sleep(2000);
        });
    });

    /*
    optie niet aanwezig momenteel ?
    it('FietsverzekeringFR: Vink optie fietsbijstand uit', function () {
        console.log('FietsverzekeringFR: Vink optie fietsbijstand uit');
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/label/app-calculator-type/div/div/span')).click();
        browser.sleep(2000);
    });*/

    it('FietsverzekeringFR: Valideer prijs calculator', function () {
        console.log('FietsverzekeringFR: Valideer prijs calculator');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            // KP-73 tijdelijke aanpassing in afwachting van nauwkeurigere prijs door KLA
            expect(updatedPricing).toBe('€ 382,01');
            // expect(updatedPricing).toBe('€ 385');
            browser.sleep(2000);
        });
    });

    it('FietsverzekeringFR: Klik op Bestel Online knop', function () {
        console.log('FietsverzekeringFR: Klik op Bestel Online knop');
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a')).click();
        browser.sleep(2000);

        console.log("FietsverzekeringFR: Ignore synchronization");
        browser.ignoreSynchronization = false;
        browser.sleep(15000);
    });


    /*keeps failing without reason
    it('FietsverzekeringFR: Valideer nieuwe pagina 1/4', function () {
        console.log('FietsverzekeringFR: Valideer nieuwe pagina 1/4');
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: pagina 1/4");

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe(common.fietsverzekeringTitleFR);
            browser.sleep(2000);
        });
    });*/
    it('FietsverzekeringFR: Framenummer invullen', function () {
        console.log("FietsverzekeringFR: Framenummer invullen");
        browser.waitForAngularEnabled(false);

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[1]/app-collapsible-area/li/div[2]/div/div/div/div[1]/app-textinput/div/div/label/div[2]/div/div/div/input')).sendKeys('123456');
    });


    it('FietsverzekeringFR: Valideer prijs calculator', function () {
        console.log('FietsverzekeringFR: Valideer prijs calculator');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            // KP-73 tijdelijke aanpassing in afwachting van nauwkeurigere prijs door KLA
            expect(updatedPricing).toBe('€ 382,01');
            // expect(updatedPricing).toBe('€ 385');
        });
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Klik op volgende', function () {
        console.log('FietsverzekeringFR: Klik op volgende');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Valideer nieuwe pagina 2/4', function () {
        console.log('FietsverzekeringFR: Valideer nieuwe pagina 2/4');
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: pagina 2/4");

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Étape 2 sur 4 : Données');
        });
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Vul persoonlijke gegevens in', function () {
        console.log('FietsverzekeringFR: Vul persoonlijke gegevens in');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[2]/span/span/app-textinput/div/div/label/div/input')).sendKeys(common.userFirstName);
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[3]/span/span/app-textinput/div/div/label/div/input')).sendKeys(common.userLastName);
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[4]/span/span/app-dateinput/div/div/label/div[1]/app-material-datepicker/div/input')).sendKeys(common.userBirthDate);
        browser.sleep(2000);
        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[3]/span/span/app-textinput/div/div/label/div/input')).click();
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Vul adres in', function () {
        console.log('FietsverzekeringFR: Vul adres in');
        // Validation needs to have sleep behind each field
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[1]/span[1]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userZipcode);
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[1]/span[2]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userCity);
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[2]/span[1]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userStreet);
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[2]/span[2]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userHouseNumber);
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Vul email gegevens in', function () {
        console.log('FietsverzekeringFR: Vul email in');
        // Validation needs to have sleep behind each field
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[4]/div[1]/div[2]/div[1]/span/span/app-emailinput/div/div/label/div/input')).sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Klik checkbox algemene voorwaarden', function () {
        console.log('FietsverzekeringFR: Klik checkbox algemene voorwaarden');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[4]/div[2]/div/div[1]/span/span/app-checkbox/div/label/span[1]')).click();
        browser.sleep(4000);
    });

    it('FietsverzekeringFR: Klik volgende knop', function () {
        console.log('FietsverzekeringFR: Klik volgende knop');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[3]/div/a[2]/span')).click();
        browser.sleep(4000);
    });

    it('FietsverzekeringFR: Valideer nieuwe pagina 3/4', function () {
        console.log('FietsverzekeringFR: Valideer nieuwe pagina 3/4');
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[1]/span/app-question/p'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: pagina 3/4");

        var myElement = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[1]/span/app-question/p'));
        expect(myElement.isPresent()).toBe(true);
        browser.sleep(2000);

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Étape 3 sur 4 : Analyse des besoins');
        });
    });

    it('FietsverzekeringFR: Vul de behoefteanalyse in', function () {
        console.log('ietsverzekeringFR: Vul de behoefteanalyse in');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[1]/span/app-question/div/label[1]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[2]/span/app-question/div/label[1]/span[1]')).click();
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Klik op volgende knop', function () {
        console.log('FietsverzekeringFR: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[3]/div/a[2]')).click();
        browser.sleep(2000);
    });

    it('FietsverzekeringFR: Valideer nieuwe pagina 4/4', function () {
        console.log('FietsverzekeringFR: Valideer nieuwe pagina 4/4');
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: pagina 4/4");

        var myElement = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        expect(myElement.isPresent()).toBe(true);

        console.log("FietsverzekeringFR: Next page");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Étape 4 sur 4 : Paiement');
        });
    });

    it('FietsverzekeringFR: Valideer prijs calculator', function () {
        console.log('FietsverzekeringFR: Valideer prijs calculator');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 382,01');
        });
    });
    if (common.payment) {

        it('Betaalstap selecteer Visa', function () {
            paymentFunctions.visaPaymentFiets();
        });
    };
});
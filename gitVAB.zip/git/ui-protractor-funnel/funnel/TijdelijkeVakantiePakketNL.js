var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
var tariffFunctions = require('./VABCommon/tariffFunctions.js');
var componentFunctions = require('./VABCommon/componentFunctions.js');

describe("TijdelijkeVakantiePakketNL: TijdelijkeVakantiePakketNL", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    var totalDays=9;
    var totalPersons=4;
    var totalTravelPrice=3000;

    var totalMonths=1;
    var totalVehicles=4;
    var maxPersons=9;
    var maxVehicles=5;
    var additionalPersons=1;
    var additionalVehicles=1;
   
	it('TijdelijkeVakantiePakketNL: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeVakantiePakketNL: Open browser & accepteer cookies");
		browser.get(applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/tijdelijke-reisbijstand/vakantiepakket-en-bagage');
		browser.sleep(4000);
		common.cookie.click();
		browser.sleep(2000);
        browser.waitForAngularEnabled(false);
	});

	it("TijdelijkeVakantiePakketNL: Valideer prijs", function () {
        console.log("TijdelijkeVakantiePakketNL: Valideer prijs");
        var priceHeader = element(by.className("vab__calculator__form__price vab__heading--1"));
        browser.wait(EC.visibilityOf(priceHeader), 50000, "Timeout of VisibilityOf: HomePage TijdelijkeVakantiePakketNL");

        console.log("TijdelijkeVakantiePakketNL: Scroll to calculator");
        browser.actions().mouseMove(element(by.className('vab__calculator__form__price vab__heading--1'))).perform();

		priceHeader.getText().then(function (defaultPrice) {
			expect(defaultPrice).toBe('€ 0');
		});
	});

	it('TijdelijkeVakantiePakketNL: Vul datums in', function () {
		console.log("TijdelijkeVakantiePakketNL: Vul datums in");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/app-text-option/div/label/div[2]/app-text-input/div/div/input')).sendKeys(totalTravelPrice);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeVakantiePakketNL: Vul start datum in', function () {
		console.log("TijdelijkeVakantiePakketNL: Vul start datum in");
		startDate = dateFunctions.addTotalDays(1);
		console.log('startdate: ' + startDate);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/h3')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeVakantiePakketNL: Vul eind datum in', function () {
		console.log("TijdelijkeVakantiePakketNL: Vul eind datum in");
		endDate = dateFunctions.addTotalDaysReferenceDate(startDate, totalDays);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);
		browser.sleep(1000);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/h3')).click();
		browser.sleep(4000);
	});

	it('TijdelijkeVakantiePakketNL: Voeg personen', function () {
        console.log("TijdelijkeVakantiePakketNL: Voeg personen toe");
        for (let i = 2; i <= totalPersons; i++) {
            console.log("TijdelijkeVakantiePakketNL: Voeg persoon toe");
            componentFunctions.addPerson();

            console.log("TijdelijkeVakantiePakketNL: Bereken prijs");
            expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,i,0);     
            
            console.log("TijdelijkeVakantiePakketNL: Valideer prijs");
            var elementPrice = element(by.className("vab__calculator__form__price vab__heading--1"));               
            componentFunctions.validatePrice(elementPrice,expectedPrice);
            
        }
    });

	it('TijdelijkeVakantiePakketNL: Voeg voertuigen toe', function () {
		console.log("TijdelijkeVakantiePakketNL: Voeg voertuigen toe");
		for (let i = 1; i <= totalVehicles; i++) {
            console.log("TijdelijkeVakantiePakketNL: Voeg voertuig toe");
            componentFunctions.addVehicle();
            console.log("TijdelijkeVakantiePakketNL: Bereken prijs");
            expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,totalPersons,i);
            
            console.log("TijdelijkeVakantiePakketNL: Valideer prijs");
            var elementPrice = element(by.className("vab__calculator__form__price vab__heading--1"));
            componentFunctions.validatePrice(elementPrice,expectedPrice);
                     
		}
	});

	it('TijdelijkeVakantiePakketNL: Klik op Bestel online', function () {
		console.log("TijdelijkeVakantiePakketNL: Klik op Bestel online");
        console.log("TijdelijkeVakantiePakketNL: Scroll en klik op knop");
       // browser.executeScript('window.scrollTo(0,5000);');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
		browser.sleep(3000);
	});

	it('TijdelijkeVakantiePakketNL: Valideer prijs', function () {
		console.log("TijdelijkeVakantiePakketNL: Valideer prijs");
		elementPrice = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span'));
        componentFunctions.validatePrice(elementPrice,expectedPrice);
	});

	it("TijdelijkeVakantiePakketNL: Valideer start datum", function () {
		console.log("TijdelijkeVakantiePakketNL: Valideer start datum");
		var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
		console.log("Start datum:" + startDate);
		expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
	});

	it("TijdelijkeVakantiePakketNL: Valideer eind datum", function () {
		console.log("TijdelijkeVakantiePakketNL: Valideer eind datum");
		var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
		console.log("Eind Datum: " + endDate);
		expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
    });
    
    it('TijdelijkeVakantiePakketNL: Vul gegevens in personen', function () {
        console.log("TijdelijkeVakantiePakketNL: Vul gegevens in personen");
        for (let i = 1; i <= totalPersons; i++) {
            componentFunctions.fillPersonInformation(i);
        }
	});
	
	it('TijdelijkeVakantiePakketNL: Voeg medereizigers toe', function () {
        console.log("TijdelijkeVakantiePakketNL: Voeg medereizigers toe");
        componentFunctions.fillAdditionalPersons(additionalPersons,totalPersons,maxPersons,totalTravelPrice,totalDays,totalMonths,totalVehicles);
    });

    
    it('TijdelijkeVakantiePakketNL: Vul gegevens in voertuigen', function () {
        console.log("TijdelijkeVakantiePakketNL: Vul gegevens in voertuigen");
        for (let i = 1; i <= totalVehicles; i++) {
            componentFunctions.fillVehicleInformation(i);
			browser.sleep(2000)
        }
    });
     
    it('TijdelijkeVakantiePakketNL: Voeg extra voertuigen toe', function () {
        console.log("TijdelijkeVakantiePakketNL: Voeg extra voertuigen toe");        
        totalPersons=totalPersons+additionalPersons;
        componentFunctions.fillAdditionalVehicles(additionalVehicles,totalVehicles,maxVehicles,totalTravelPrice,totalDays,totalMonths,totalPersons);
		browser.sleep(1000);
    });

    it('TijdelijkeVakantiePakketNL: Klik op volgende knop', function () {
		console.log("TijdelijkeVakantiePakkentNL: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
		browser.sleep(3000);
    });

	it('TijdelijkeVakantiePakketNL: Vul gegevens in', function () {
		console.log("TijdelijkeVakantiePakketNL: Vul gegevens in");
        componentFunctions.fillPersonalData();
		browser.sleep(2000);
		console.log('TijdelijkeVakantiePakketNL: Checkbox algemene voorwaarden')
		element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label/span[1]')).click();
		browser.sleep(2000);
	});

	/*it('TijdelijkeVakantiePakketNL: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeVakantiePakketNL: Klik checkbox algemene voorwaarden");
		common.checkbox.click();
		browser.sleep(2000);
	});*/

	it('TijdelijkeVakantiePakketNL: Klik op volgende knop', function () {
		console.log("TijdelijkeVakantiePakketNL: Klik op volgende knop");
		browser.sleep(2000);
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeVakantiePakketNL: Vul behoefteanalyse pagina in', function () {
        console.log("TijdelijkeVakantiePakketNL: Vul behoefteanalyse pagina in");
        componentFunctions.fillBehoefteAnalyse();
	});

	it('TijdelijkeVakantiePakketNL: Klik op toon resultaat', function () {
		console.log("TijdelijkeVakantiePakketNL: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeVakantiePakketNL: Valideer resultaat tekst', function () {
		console.log("TijdelijkeVakantiePakketNL: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]')).getText().then(function (text) {
			expect(text).toBe("Het gekozen product voldoet aan jouw behoeften. Klik op 'volgende' om verder te gaan met je gekozen product.");
		});
	});

	it('TijdelijkeVakantiePakketNL: Klik op volgende knop', function () {
		console.log("TijdelijkeVakantiePakketNL: Klik op volgende knop");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(4000);
	});

	if (common.payment) {
		it('TijdelijkeVakantiePakketNL: Betaalstap selecteer VISA', function () {
            console.log("TijdelijkeVakantiePakketNL: Betaalstap selecteer VISA");
			paymentFunctions.visaPayment();
		});
	};
});
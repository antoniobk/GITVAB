var Common = require('./VABCommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("BijstandspakketSingleNL: Buy a product: Bijstandspakket Single", function () {
	console.log('BijstandspakketSingleNL: Order a Bijstandspakket Single');
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	it('BijstandspakketSingleNL: Open browser & accepteer cookies', function () {
		console.log('BijstandspakketSingleNL: Open browser & accepteer cookies');
		browser.get(applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/bijstandspakket');
		browser.sleep(2000);
		common.cookie.click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Valideer prijs', function () {
		console.log('BijstandspakketSingleNL: Valideer prijs');
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage Bijstands pakket");

		element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Bereken je tarief');
		});
        console.log("BijstandspakketSingleNL: Scroll to calculator");
        browser.actions().mouseMove(element(by.className('vab__calculator__form__price vab__heading--1'))).perform();

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 230');
		});
	});

	it('BijstandspakketSingleNL: Voeg extra voertuig toe', function () {
		console.log('BijstandspakketSingleNL: Voeg extra voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 342');
		});
	});

	it('BijstandspakketSingleNL: Voeg extra vervangwagen toe', function () {
		console.log('BijstandspakketSingleNL: Voeg extra vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 428');
		});

		console.log('BijstandspakketSingleNL: Voeg extra vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 514');
		});

	});

	it('BijstandspakketSingleNL: Voeg optie camper toe', function () {
		console.log('BijstandspakketSingleNL: Voeg optie camper toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 610');
		});
	});

	it('BijstandspakketSingleNL: Voeg optie annulatieverzekering toe', function () {
		console.log('BijstandspakketSingleNL: Voeg optie annulatieverzekering toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[4]/div/label/div/div/span')).click();
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 719');
		});
	});

	it('BijstandspakketSingleNL: Klik op volgende knop', function () {
		console.log('BijstandspakketSingleNL: Klik op volgende knop');
        console.log("BijstandspakketSingleNL: Scroll en klik op knop");
        browser.executeScript('window.scrollTo(0,2000);');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Valideer nieuwe pagina 1/4', function () {
		console.log('BijstandspakketSingleNL: Valideer nieuwe pagina 1/4');
		var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw VAB-Bijstandspakket");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 1 van 4: Jouw VAB-Bijstandspakket');
		});
	});

	it('BijstandspakketSingleNL: Valideer prijs', function () {
		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 719');
		});
	});

	it('BijstandspakketSingleNL: Vul gegevens in', function () {
		console.log('BijstandspakketSingleNL: Vul gegevens in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Validation needs to have focus
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Vul nummerplaten in', function () {
		console.log('BijstandspakketSingleNL: Vul nummerplaten in');
		console.log('BijstandspakketSingleNL: Nummerplaat 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('VROOM1');
		browser.sleep(2000);

		console.log('BijstandspakketSingleNL: Nummerplaat 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('VROOM2');
		browser.sleep(2000);

		// Validation needs to have focus
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);

	});

	it('BijstandsPakketSingleNL: Bevestig dat gegevens correct zijn', function () {
		console.log('BijstandsPakketSingleNL: Bevestig dat gegevens correct zijn');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
	})
	it('BijstandspakketSingleNL: Klik op volgende knop', function () {
		console.log('BijstandspakketSingleNL: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
		browser.sleep(2000);
		browser.ignoreSynchronization = true;
	});

	it('BijstandspakketSingleNL: Valideer nieuwe pagina 2/4', function () {
		console.log('BijstandspakketSingleNL: Valideer nieuwe pagina 2/4');
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 2 van 4: Gegevens');
		});

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 719');
		});
	});


	it('BijstandspakketSingleNL: Vul adres in', function () {
		console.log('BijstandspakketSingleNL: Vul adres in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Vul email in', function () {
		console.log('BijstandspakketSingleNL: Vul email in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Klik checkbox algemene voorwaarden', function () {
		console.log('BijstandspakketSingleNL: Klik checkbox algemene voorwaarden');
		common.checkboxGeneralTerms.click();
	});

	it('BijstandspakketSingleNL: Klik op volgende knop', function () {
		console.log('BijstandspakketSingleNL: Klik op volgende knop');
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Valideer nieuwe pagina 3/4', function () {
		console.log('BijstandspakketSingleNL: Valideer nieuwe pagina 3/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 3 van 4: Behoefteanalyse');
		});

		console.log('BijstandspakketSingleNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 719');
		});
	});

	it('BijstandspakketSingleNL: Vul behoefteanalyse pagina in', function () {
		console.log('BijstandspakketSingleNL: Vul behoefteanalyse pagina in');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Klik op toon resultaat', function () {
		console.log('BijstandspakketSingleNL: Klik op toon resultaat');
		element(by.id('submitBtn')).click();
		browser.sleep(5000);
	});

	it('BijstandspakketSingleNL: Valideer resultaat tekst', function () {
		console.log('BijstandspakketSingleNL: Valideer resultaat tekst');
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe(common.behoefteAnalyseTijdelijkeNL);
			browser.sleep(6000);
		});
	});

	it('BijstandspakketSingleNL: Klik op volgende knop', function () {
		console.log('BijstandspakketSingleNL: Klik op volgende knop');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(2000);
	});

	it('BijstandspakketSingleNL: Valideer nieuwe pagina 4/4', function () {
		console.log('BijstandspakketSingleNL: Valideer nieuwe pagina 4/4');
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/div[1]/div[1]/p'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 4 van 4: Betaling");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 4 van 4: Betaling');
		});

		console.log('BijstandspakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 719');
		});
	});

	it('BijstandspakketSingleNL: Vul vouchercode in', function () {
		console.log('BijstandspakketSingleNL: Vul vouchercode in');
        paymentFunctions.setVoucherCode(false);

		console.log('BijstandspakketSingleNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 619,39');
		});
	});
	if (common.payment) {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});

var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');

describe("TijdelijkeReisbijstandFR", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('TijdelijkeReisbijstandFR: Open browser & accepteer cookies', function () {
        console.log("TijdelijkeReisbijstandFR: Open browser & accepteer cookies");
        browser.waitForAngularEnabled(false);
        browser.get(applicationURL + '/fr/assistance/assistance-voyage/assistance-voyage-temporaire');

        browser.wait(EC.visibilityOf(common.cookie), 30000, "Timeout of VisibilityOf: Bijstand auto en motor");
        common.cookie.click();
        browser.waitForAngularEnabled(false);
    });

    it("TijdelijkeReisbijstandFR: Klik op Commandez", function () {
        console.log("TijdelijkeReisbijstandFR: Klik op Commandez");
        element(by.xpath('/html/body/section[6]/div/ul/li[1]/ul/li[1]/div/div[4]/a')).click();
    });

    it("TijdelijkeReisbijstandFR: wacht op pagina tijdelijke reisbijstand", function () {
        console.log("TijdelijkeReisbijstandFR: wacht op pagina reisbijstand");
        var ele = element(by.className("vab__intro__title vab__heading--2 ng-star-inserted"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: HomePage of Tijdelijke reisbijstand");
    });

    it("TijdelijkeReisbijstandFR: Scroll naar calculator", function () {
        console.log("TijdelijkeReisbijstandFR: Scrollen naar calculator");
        var elementToScrollTo = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p/span'));
        browser.actions().mouseMove(elementToScrollTo).perform();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPrice) {
            expect(defaultPrice).toBe('€ 0');
        });
    });

    it("TijdelijkeReisbijstandFR: Vul begindatum  reis in", function () {
        console.log("TijdelijkeReisbijstandFR: Invullen datum begin reis: ");
        startDate = dateFunctions.addTotalDays(1);;
        console.log('startdate: ' + startDate);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/div/label/div[2]/app-new-datepicker/div[1]/input')).sendKeys(startDate);
        browser.sleep(8000);
        //Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).click();
        browser.sleep(4000);
    });

    it("TijdelijkeReisbijstandFR: Vul eind datum reis in", function () {
        console.log("TijdelijkeReisbijstandFR: Invullen datum einde reis: ");
        endDate = dateFunctions.addTotalDays(8);
        console.log('enddate: ' + endDate);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);
        browser.sleep(8000);

        //Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).click();
        browser.sleep(4000)
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (priceAfterDate) {
            expect(priceAfterDate).toBe('€ 25');
        });
    });

    it("TijdelijkeReisbijstandFR: Voeg personen toe", function () {
        console.log("TijdelijkeReisbijstandFR: Voeg personen toe");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (priceWith3) {
            expect(priceWith3).toBe('€ 50');
        });
    });

    it("TijdelijkeReisbijstandFR: Selecteer internationaal", function () {
        console.log("TijdelijkeReisbijstandFR: Selecteer internationaal");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/div/div[2]/div/div/label/span[1]')).click();
        browser.sleep(5000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (pricerAfterInternational) {
            expect(pricerAfterInternational).toBe('€ 96');
        });
    });

    it("TijdelijkeReisbijstandFR: Klik op Achetez en ligne", function () {
        console.log("TijdelijkeReisbijstandFR: Klik op Achetez en ligne");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a')).click();
        browser.sleep(5000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 96');
        });
    });

    it("TijdelijkeReisbijstandFR: Valideer start datum", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer start datum");
        var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
        // gebruik getAttribute('value') ipv van getText(), omdat het een input field is.
        expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
    });

    it("TijdelijkeReisbijstandFR: Valideer eind datum", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer eind datum");
        var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
        // gebruik getAttribute('value') ipv van getText(), omdat het een input field is.
        expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
    });

    it("TijdelijkeReisbijstandFR: Voer gegevens persoon 1 in", function () {
        console.log("TijdelijkeReisbijstandFR: Voer gegevens persoon 1 in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[1]/div/div[1]/label[1]/input')).sendKeys("VABVOORNAAMTST");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[1]/div/div[1]/label[2]/input')).sendKeys("VABACHTERNAAMTST");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[1]/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys("1994/12/1996");
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Wijzig focus door validatie", function () {
        console.log("TijdelijkeReisbijstandFR: Wijzig focus door validatie");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Voer gegevens persoon 2 in", function () {
        console.log("TijdelijkeReisbijstandFR: Voer gegevens persoon 2 in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[1]/input')).sendKeys("VABVOORNAAMTST2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[2]/input')).sendKeys("VABACHTERNAAMTST2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys("1990/10/1992");
        browser.sleep(2000);
        
        //Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Voeg persoon 3 toe", function () {
        console.log("TijdelijkeReisbijstandFR: Voeg persoon toe");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div'));
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div/span/i')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Voeg gegevens persoon 3 in", function () {
        console.log("TijdelijkeReisbijstandFR: Voer gegevens persoon 3 in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[3]/div/div[1]/label[1]/input')).sendKeys(common.userLastName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[3]/div/div[1]/label[2]/input')).sendKeys(common.userFirstName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[3]/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
        browser.sleep(2000);

        // Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 144');
        });
    });

    it("TijdelijkeReisbijstandFR: Klikken op volgende knop", function () {
        console.log("TijdelijkeReisbijstandFR: Klikken op volgende knop");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Vul contactgegevens in:", function () {
        console.log("TijdelijkeReisbijstandFR: Vul contactgegevens in");
        common.zipcode.sendKeys(common.userZipcode);
        browser.sleep(2000);

        common.city.sendKeys(common.userCity);
        browser.sleep(2000);

        common.street.sendKeys(common.userStreet);
        browser.sleep(2000);

        common.houseNumber.sendKeys(common.userHouseNumber);
        browser.sleep(2000);

        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandFR: Bevestig correcte gegevens", function () {
        console.log("TijdelijkeReisbijstandFR: Bevestig correcte gegevens");
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label/span[1]')).click();
    });

    it("TijdelijkeReisbijstandFR: Klik op volgende knop", function () {
        console.log("TijdelijkeReisbijstandFR: Klik op volgende knop");
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div/button[2]')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Vul behoefteanalyse in", function () {
        console.log("TijdelijkeReisbijstandFR: Vul behoefteanalyse in");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[1]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[2]/span[1]')).click();
    });

    it("TijdelijkeReisbijstandFR: Klikken op toon resultaat", function () {
        console.log("TijdelijkeReisbijstandFR: Klikken op toon resultaat");
        element(by.id('submitBtn')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Klik op volgende knop", function () {
        console.log("TijdelijkeReisbijstandFR: Klik op volgende knop");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandFR: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandFR: Valideer prijs");
        element(by.xpath('//*[@id="funnelStep2Calc"]/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 144');
        });
    });

    if (common.payment) {
        it('TijdelijkeReisbijstandFR: Selecteer CBC', function () {
            paymentFunctions.cbcPayment();
        });
    };
});
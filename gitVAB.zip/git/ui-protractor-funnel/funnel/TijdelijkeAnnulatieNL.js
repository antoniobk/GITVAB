var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("TijdelijkeAnnulatieNL: Tijdelijke reisverzekering: Annulatie", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	it('TijdelijkeAnnulatieNL: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeAnnulatieNL: Open browser & accepteer cookies");
		browser.get(applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/tijdelijke-reisbijstand/annulatieverzekering');
		browser.sleep(2000);
		common.cookie.click();
		browser.sleep(2000);
		browser.waitForAngularEnabled(false);
	});

	it('TijdelijkeAnnulatieNL: Valideer prijs', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer prijs");
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage of Tijdelijke reisbijstand");
		browser.waitForAngular;

		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 0');
		});
	});

	it('TijdelijkeAnnulatieNL: Vul totaal reissom in', function () {
		console.log("TijdelijkeAnnulatieNL: Vul totaal reissom in");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/app-text-option/div/label/div[2]/app-text-input/div/div/input')).sendKeys(250);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);

		console.log('TijdelijkeAnnulatieNL: Vul startdatum in');
		var startDate = dateFunctions.getFutureDate(1, 1);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);

		console.log('TijdelijkeAnnulatieNL: Vul einddatum in');
		var endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 27);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);

		// Wijzig focus door validaties
		element(by.className('vab__calculator__form__theHeading')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Voeg aantal personen toe', function () {
		console.log("TijdelijkeAnnulatieNL: Voeg aantal personen toe");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Valideer prijs ', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer prijs");
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 25');
		});
		browser.sleep(5000);

	});

	it('TijdelijkeAnnulatieNL: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieNL: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Valideer nieuwe pagina 1/4', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer nieuwe pagina 1/4");
		var ele = element(by.className("vab__calculator__form__price"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw Tijdelijke annulatieverzekering");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultTitle) {
			expect(defaultTitle).toBe(common.tijdelijkeAnnulatieTitelNL);
		});
	});


	it('TijdelijkeAnnulatieNL: Vul gegevens in persoon 1', function () {
		console.log("TijdelijkeAnnulatieNL: Vul gegevens in persoon 1");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Vul gegevens in persoon 2', function () {
		console.log("TijdelijkeAnnulatieNL: Vul gegevens in persoon 2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).sendKeys(common.userFirstName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[2]/input')).sendKeys(common.userLastName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Valideer prijs', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer prijs");
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 25');
			browser.sleep(2000);
		});
	});

	it('TijdelijkeAnnulatieNL: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieNL: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
		browser.sleep(5000);
	});

	it('TijdelijkeAnnulatieNL: Valideer nieuwe pagina 2/4', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer nieuwe pagina 2/4");
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 25');
		});
	});

	it('TijdelijkeAnnulatieNL: Vul adres in', function () {
		console.log("TijdelijkeAnnulatieNL: Vul adres in");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);

	});

	it('TijdelijkeAnnulatieNL: Vul email in', function () {
		console.log("TijdelijkeAnnulatieNL: Vul email in");
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeAnnulatieNL: Klik checkbox algemene voorwaarden");
		common.checkbox.click();
	});

	it('TijdelijkeAnnulatieNL: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieNL: Klik op volgende knop");
		browser.sleep(2000);
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Valideer nieuwe pagina 3/4', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer nieuwe pagina 3/4");
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 25');
		});
	});

	it('TijdelijkeAnnulatieNL: Vul behoefteanalyse pagina in', function () {
		console.log("TijdelijkeAnnulatieNL: Vul behoefteanalyse pagina in");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Klik op toon resultaat', function () {
		console.log("TijdelijkeAnnulatieNL: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Valideer resultaat tekst', function () {
		console.log("TijdelijkeAnnulatieNL: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe(common.behoefteAnalyseTijdelijkeNL);
		});
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieNL: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieNL: Klik op volgende knop");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(4000);

	});
	if (common.payment) {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});



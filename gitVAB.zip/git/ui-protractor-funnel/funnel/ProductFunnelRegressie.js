var jasmineReporters = require('jasmine-reporters');
var commonFunctions = require('./VABCommon/commonFunctions.js');

exports.config = {
  framework: 'jasmine',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  //directConnect:true,
  getPageTimeout: 500000,
  jasmineNodeOpts: {
    defaultTimeoutInterval: 200000
  },
  capabilities: {
    browserName: 'chrome',
    platform: 'windows',
    shardTestFiles: true,
    maxInstances: 1
  },
  params: { 
    environment: "acc",
    // Activeer accept all cookies: element(by.xpath('//*[@id="CybotCookiebotDialogBodyButtonAccept"]')),
    cookie: '//*[@id="CybotCookiebotDialogBodyButtonDecline"]'
  },
  specs: [
    'FietsverzekeringNL.js',              // #0
    'ReisbijstandSingleNL.js',            // #1
    'PechbijstandNL.js',                  // #2
    'MotorbijstandJaarNL.js',             // #3
    'FietsbijstandSingleNL.js',           // #4
    'AnnulatieverzekeringSingleNL.js',    // #5
    'BijstandspakketSingleNL.js',         // #6
//    'VakantiepakketSingleNL.js',          // #7    
//    'VakantiepakketGezinFR.js',           // #8
    'MultipakketSingleNL.js',             // #9
    'MultipakketGezinFR.js',              // #10
   'FietsverzekeringFR.js',              // #11
 // 'MotorbijstandSeizoenFR.js',        // #12
   'PechbijstandFR.js',                  // #13
    'FietsbijstandDuoFR.js',              // #14
// 'ReisbijstandGezinFR.js',             // #15
    'AnnulatieverzekeringGezinFR.js',     // #16
    'BijstandspakketGezinFR.js',          // #17
    'TijdelijkeBagageNL.js',              // #18
    'TijdelijkeBagageFR.js',              // #19
    'TijdelijkeAnnulatieNL.js',           // #20
    'TijdelijkeReisbijstandFR.js',        // #21
    'TijdelijkeAnnulatieFR.js',           // #22
    'TijdelijkeVakantiepakketNL.js' ,     // #23
    'TijdelijkeReisbijstandNL.js',        // #24
    'TijdelijkeVakantiepakketFR.js',      // #25
    //'TijdelijkeReisbijstandBagageNL.js',  // #26
    //'TijdelijkeReisbijstandBagageFR.js'   // #27  
  ],
  exclude: [
  ],
  onPrepare: function () {
    //Maximize
    browser.driver.manage().window().maximize();
    var reportsDirectory = commonFunctions.getEnvironmentReportsDirectory(browser.params.environment);
    
    //xml report generated for Azure DevOps
    jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
      consolidateAll: false,
      savePath: reportsDirectory,
      filePrefix: 'xmlOutput'
    }));
  }
};




/*

browserNames:
* MicrosoftEdge : https://stackoverflow.com/questions/47891742/how-to-configure-protractor-js-for-running-tests-in-microsoft-edge
* chrome
* firefox
* safari
* internet explorer

Don't forget to install all drivers for the correct versions
Don't forget firefox brings issues for compatibility, they made some changes so you'll have to use firefox version 47 and not higher. (or use heavy workarounds)


*/
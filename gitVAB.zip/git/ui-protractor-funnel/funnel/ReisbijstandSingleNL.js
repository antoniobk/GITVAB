var Common = require('./VABcommon/common');
var dateFunctions = require('./VABCommon/dateFunctions');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');

describe('ReisbijstandSingleNL: Buy a product', function () {
    console.log('ReisbijstandSingleNL: start tests reisbijstandSingleNL');
    var common = new Common();
    var EC = protractor.ExpectedConditions;
    var applicationURL = common.applicationURL;

    it('ReisbijstandSingleNL: Open browser & accepteer cookies', function () {
        console.log('ReisbijstandSingleNL: Open browser & accepteer cookies');
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/reisbijstand');
        browser.sleep(4000);
        common.cookie.click();
        browser.sleep(4000);
    });

    it('ReisbijstandSingleNL: Valideer prijs', function () {
        console.log('ReisbijstandSingleNL: Valideer prijs');
        var ele = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/div/div/div/div[1]/header'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout on VisibilityOf: Reisbijstand homepage");

        var myElement = element(by.className('vab__intro__title vab__heading--2'));
        expect(myElement.isPresent()).toBe(true);
        
        console.log("ReisbijstandSingleNL: Scroll to calculator");
        browser.actions().mouseMove(element(by.className('vab__calculator__form__price vab__heading--1'))).perform();

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 94');
        });
    });


    it('ReisbijstandSingleNL: Extra opties', function () {
        console.log('ReisbijstandSingleNL: Voertuig toevoegen');
        element(by.xpath('/html/body/section[3]/app-root/app-dynamic-component/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 139');
        });

      //  console.log("ReisbijstandSingleNL: Scroll");
      //  browser.executeScript('window.scrollTo(0,2500);');
    })

    it('ReisbijstandSingleNL: Extra opties', function () {
        console.log('ReisbijstandsSingleNL: Vervangwagen toevoegen')
        element(by.xpath('/html/body/section[3]/app-root/app-dynamic-component/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 192');
        });
    })

    it('ReisbijstandSingleNL: Voeg motorhome toe toe', function () {
        console.log('ReisbijstandSingleNL: Voeg motorhome toe');
        element(by.xpath('/html/body/section[3]/app-root/app-dynamic-component/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 261');
        });
    })
    it('ReisbijstandSingleNL: Voeg bagageverzekering toe', function () {
        console.log('ReisbijstandSingleNL: Voeg bagageverzekering toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[4]/div/label/div/div/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 370');
        });
    })

    it('ReisbijstandSingleNL: Klik op volgende knop"', function () {
        console.log('ReisbijstandSingleNL: Klik op bestel online');
        element(by.xpath('/html/body/section[3]/app-root/app-dynamic-component/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
        browser.sleep(2000);
    });

    /*it('ReisbijstandSingleNL: Valideer nieuwe pagina 1/4', function () {
        console.log('ReisbijstandSingleNL: Valideer nieuwe pagina 1/4');
        var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[1]/a/div'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout on VisibilityOf: Reisbijstand Stap 1");

        element(by.className("h1 vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 1 van 4: Jouw VAB-Reisbijstand');
        });

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 370');
        });
    });*/

    it('ReisbijstandSingleNL: Vul gegevens in', function () {
        console.log('ReisbijstandSingleNL: Vul gegevens in');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[1]/input')).sendKeys('TESTVAB-Firstname');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[2]/input')).sendKeys('TESTVAB-Lastname');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Voer nummerplaat in', function () {
        console.log('ReisbijstandSingleNL: Voer nummerplaat in');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('XYZ-987');

        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Voeg medereiziger toe', function () {
        console.log('ReisbijstandSingleNl: Voeg medereiziger toe');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/label[1]/span[1]')).click();
        browser.sleep(3000);

        console.log('ReisbijstandSingleNL: Klik op wereldwijd');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/div/label[2]/span[1]')).click();
        browser.sleep(5000);

        console.log('ReisbijstandSingleNL: Vul einddatum reis in');
        var date2 = new Date();
        date2.setDate(date2.getDate() + 2);

        var day = date2.getDate();
        var month = date2.getMonth() + 1;
        var year = date2.getFullYear();

        var endDate2 = day + "/" + month + "/" + year;
        
        console.log("endDate2 = " + endDate2)
        
        var endFormattedDate=dateFunctions.addTotalDays(2);
        console.log("endFormattedDate = " + endFormattedDate)

        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endFormattedDate);
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Valideer prijs', function () {
        console.log('ReisbijstandSingleNl: Valideer prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 395');
        });
    });

    it('ReisbijstandSingleNL: Medereiziger 1', function () {
        console.log('ReisbijstandSingleNL: Medereiziger 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).sendKeys('TESTVAB_First');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[2]/input')).sendKeys('TESTVAB_Last');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="desktopHelp"]/div/p[1]')).click();
        browser.sleep(10000);
    });

    

    it('ReisbijstandSingleNL: Selecteer checkbox goed ingevuld', function () {
        console.log('ReisbijstandSingle: Selecteer checkbox goed ingevuld');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
        browser.sleep(10000);
    })

    it('ReisbijstandSingleNL: Klik op volgende knop', function () {
        console.log('ReisbijstandSingleNL: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
        browser.sleep(10000);
        browser.ignoreSynchronization = true;
    });

    it('ReisbijstandSingleNL: Valideer nieuwe pagina 2/4', function () {
        console.log('ReisbijstandSingleNL: Valideer nieuwe pagina 2/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 2 van 4: Gegevens');
        });

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 395');
        });
    });

    it('ReisbijstandSingleNL: Vul gegevens in', function () {
        console.log("ReisbijstandSingleNL: Vul gegevens in");
        element(by.id('PersonalDataViewModel_FirstName')).clear();
        element(by.id('PersonalDataViewModel_LastName')).clear();
        element(by.id('PersonalDataViewModel_BirthdateText')).clear();

        element(by.id('PersonalDataViewModel_FirstName')).sendKeys('Nico');  // Voornaam moet gekend zijn in Sparta voornamenlijst, anders worden voornaam en naam geconcateneerd
        element(by.id('PersonalDataViewModel_LastName')).sendKeys('TESTVAB');
        element(by.id('PersonalDataViewModel_BirthdateText')).sendKeys('13/10/1999');
        browser.sleep(2000);
    });
    it('ReisbijstandSingleNL: Vul adres in', function () {
        console.log('ReisbijstandSingleNL: Vul adres in');
        element(by.id('PersonalDataViewModel_AddressViewModel_ZipCode')).sendKeys('3201');
        element(by.id('PersonalDataViewModel_AddressViewModel_City')).sendKeys('Langdorp');
        element(by.id('PersonalDataViewModel_AddressViewModel_Street')).sendKeys('Blakerstraat');
        element(by.id('PersonalDataViewModel_AddressViewModel_Number')).sendKeys('50');
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Vul email in', function () {
        console.log('ReisbijstandSingleNL: Vul email in');
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).clear();
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Klik checkbox algemene voorwaarden', function () {
        console.log('ReisbijstandSingleNL: Klik checkbox algemene voorwaarden');
        common.checkboxGeneralTerms.click();
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Klik op volgende knop', function () {
        console.log('ReisbijstandSingleNL Klik op volgende knop');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div/button[2]/span')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL:Valideer nieuwe pagina 3/4', function () {
        console.log('ReisbijstandSingleNL Valideer nieuwe pagina 3/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 3 van 4: Behoefteanalyse');
        });

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 395');
        });
    });

    it('ReisbijstandSingleNL: Vul behoefteanalyse pagina in', function () {
        console.log('ReisbijstandSingleNL: Vul behoefteanalyse pagina in')
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[2]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[2]/span[2]')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandSingleNL: Klik op toon resultaat', function () {
        console.log('ReisbijstandSingleNL: Klik op toon resultaat');
        element(by.id('submitBtn')).click();
        browser.sleep(4000);
    });

    it('ReisbijstandSingleNL: Valideer resultaat tekst', function () {
        console.log("ReisbijstandSingleNL: Valideer resultaat tekst");
        element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
            expect(text).toBe('Op basis van jouw antwoorden stellen we het volgende product voor: VAB-Multipakket single');
        });
    });

    it('ReisbijstandSingleNL: Klik op volgende knop', function () {
        console.log('ReisbijstandSingleNL: Klik op volgende knop');
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]')).click();
        browser.sleep(4000);
    });

    it('ReisbijstandSingleNL: Valideer nieuwe pagina 4/4', function () {
        console.log('ReisbijstandSingleNL: Valideer nieuwe pagina 4/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 4 van 4: Betaling');
        });

        console.log('ReisbijstandSingleNL: Valideer prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 395');
        });
    });
    if (common.payment) {
        it('ReisbijstandSingleNL: Betaalstap selecteer MasterCard', function () {
            paymentFunctions.masterCardPayment();
        });
    };
});

var Common = require('./VABCommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("MotorBijstandSeizoenFR: Buy a product: Motor", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('MotorBijstandSeizoenFR:Open browser & accepteer cookies', function () {
        console.log('MotorBijstandSeizoenFR: Open browser & accepteer cookies');
        browser.get(applicationURL + '/fr/assistance/assistance-depannage/assistance-moto');
        browser.sleep(2000);
        common.cookie.click();
        browser.sleep(2000);

    });

    it('MotorBijstandSeizoenFR: Valideer prijs', function () {
        browser.actions().mouseMove(element(by.className('vab__calculator__form__price vab__heading--1'))).perform();
        console.log('MotorBijstandSeizoenFR: Valideer prijs');
        var myElement = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/p'));
        expect(myElement.isPresent()).toBe(true);

        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 79');
        });
    });

    

    it('MotorBijstandSeizoenFR: Voeg extra motor toe', function () {
        console.log('MotorBijstandSeizoenFR: Voeg extra motor toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Valideer prijs', function () {
        console.log("MotorBijstandSeizoenFR: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 158');
        });
    });

    it('MotorBijstandSeizoenFR: Klik op volgende knop', function () {
        console.log('MotorBijstandSeizoenFR: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Valideer nieuwe pagina 1/3', function () {
        console.log('MotorBijstandSeizoenFR: Valideer nieuwe pagina 1/3');
        element(by.className("h1 vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 1 sur 3 : Votre VAB-Assistance Moto');
        });
    });

    it('MotorBijstandSeizoenFR: Valideer prijs', function () {
        console.log('MotorBijstandSeizoenFR: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 158');
        });
    });

    it('MotorBijstandSeizoenFR: Vul nummerplaten in', function () {
        console.log('MotorBijstandSeizoenFR: Vul nummerplaten in');
        common.licensePlateOne.sendKeys("ABCDEF");
        common.licensePlateTwo.sendKeys("A23456");
    });

    it('MotorBijstandSeizoenFR: Klik op volgende knop', function () {
        console.log('MotorBijstandSeizoenFR: Klik op volgende knop');
        element(by.className("vab__button__icon vab__icon--chevron-right")).click();
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Valideer nieuwe pagina 2/3', function () {
        console.log("MotorBijstandSeizoenFR: Valideer nieuwe pagina 2/3");
        browser.waitForAngularEnabled(false);
        browser.wait(EC.visibilityOf(element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p'))), 10000, "Timeout of VisibilityOf: Stap 2 van 3: Gegevens");

        element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Étape 2 sur 3 : Données');
        });
    });

    it('MotorBijstandSeizoenFR: Valideer prijs', function () {
        console.log('MotorBijstandSeizoenFR: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing3) {
            expect(updatedPricing3).toBe('€ 158');
        });
    });

    it('MotorBijstandSeizoenFR: Vul gegevens in', function () {
        console.log('MotorBijstandSeizoenFR: Vul gegevens in');
        common.firstName.sendKeys("TESTVAB");
        common.lastName.sendKeys("Protractor");
        common.datepicker.sendKeys("13/08/1991");
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Vul adres in', function () {
        console.log('MotorBijstandSeizoenFR: Vul adres in');
        common.zipcode.sendKeys("3200");
        common.city.sendKeys("Aarschot");
        common.street.sendKeys("Schransstraat");
        common.houseNumber.sendKeys("50");
    });

    it('MotorBijstandSeizoenFR: Vul email in', function () {
        console.log('MotorBijstandSeizoenFR: Vul email in');
        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Klik checkbox algemene voorwaarden', function () {
        console.log('MotorBijstandSeizoenFR: Klik checkbox algemene voorwaarden');
        common.checkboxGeneralTerms.click();
    });

    it('MotorBijstandSeizoenFR: Klik checkbox domiciliëring', function () {
        console.log('MotorBijstandSeizoenFR: Klik checkbox domiciliëring');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[2]/span[1]')).click();
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Vul IBAN in', function () {
        console.log('MotorBijstandSeizoenFR: Vul IBAN in');
        common.IBAN.sendKeys(common.userValidIBAN);
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Klik op volgende knop', function () {
        console.log("MotorBijstandSeizoenFR: Klik op volgende knop");
        browser.sleep(2000);
        common.nextButton.click();
        browser.sleep(2000);
    });

    it('MotorBijstandSeizoenFR: Valideer nieuwe pagina 3/3', function () {
        console.log('MotorBijstandSeizoenFR: Valideer nieuwe pagina 3/3');
        element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (text) {
            expect(text).toBe('Étape 3 sur 3 : Paiement');
        });
    });

    it('MotorBijstandSeizoenFR: Valideer prijs', function () {
        console.log('MotorBijstandSeizoenFR: Valideer prijs');
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing4) {
            expect(updatedPricing4).toBe('€ 148');
        });
    });
    if (common.payment) {
        it(' Selecteer CBC', function () {
            paymentFunctions.cbcPayment();
        });
    };
});
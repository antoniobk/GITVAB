var Common = require('./VABcommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("PechbijstandFR: Aankoop van product Pechbijstand (FR)\n", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	

	it('PechbijstandFR: Open browser & accepteer cookies', function () {
		console.log('PechbijstandFR: Open browser & accepteer cookies');
		browser.waitForAngularEnabled(false);
		browser.get(applicationURL + '/fr/assistance/assistance-depannage');
		browser.sleep(5000);
		common.cookie.click();
		browser.sleep(4000);
	});

	it('PechbijstandFR: Valideer pagina Auto en motor', function () {
		console.log('PechbijstandFR: Valideer pagina Auto en motor');
		var ele = element(by.xpath("/html/body/section[2]/div"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Auto en motor");

		var myElement = element(by.className('vab__intro__title vab__heading--1'));
		expect(myElement.isPresent()).toBe(true);
		element(by.className('vab__intro__title vab__heading--1')).getText().then(function (PechTitel) {
			expect(PechTitel).toBe(common.pechbijstandTitelFR);
		});
	});

	it('PechbijstandFR: Navigeer naar pagina Pechbijstand', function () {
		console.log('PechbijstandFR: Navigeer naar pagina Pechbijstand');
		element(by.xpath('/html/body/section[5]/div/ul/li/ul/li[1]/div/div[4]/a/span')).click();
		browser.sleep(2000);
	});

	it('PechbijstandFR: Valideer prijs', function () {
		console.log('PechbijstandFR: Valideer prijs');
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Pechbijstand");
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 131');
		});
	});

	it('PechbijstandFR: Voeg een extra voertuig toe', function () {
		console.log('PechbijstandFR: Selecteer optie bestaande klant - extra voertuig');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();

		console.log('PechbijstandFR: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 131');
		});
	});

	it('PechbijstandFR: Voeg een vervangwagen toe', function () {
		console.log('PechbijstandFR: Voeg een vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('PechbijstandFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 303');
		});
	});

	it('PechbijstandFR: Klik op bestel online knop', function () {
		browser.executeScript('window.scrollTo(0,1000);');
		browser.sleep(2000);
		console.log('PechbijstandFR: Klik op bestel online knop');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('PechbijstandFR: Valideer pagina - stap 1. Product', function () {
		console.log('PechbijstandFR: Valideer pagina - stap 1. Product');
		var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 3: Jouw VAB-Pechbijstand");

		console.log('PechbijstandFR: Stap 1. Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 303');
		});
	});

/*	it('PechbijstandFR: Stap 1. Voer lidnummer in', function () {
		console.log('PechbijstandFR: Stap 1. Voer lidnummer in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/div/label[1]/span[1]')).click();
		//element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/div/label[2]/input')).sendKeys('65275069');
		browser.sleep(2000);
	});*/

	it('PechbijstandFR: Stap 1. Voer gegevens voertuig 1 in', function () {
		console.log('PechbijstandFR: Stap 1. Voer gegevens voertuig 1 in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('1-VAB-001');
		browser.sleep(2000);
	});

	it('PechbijstandFR: Stap 1. Voer gegevens voertuig 2 in', function () {
		console.log('PechbijstandFR: Stap 1. Voer gegevens voertuig 2 in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('1-VAB-002');
		browser.sleep(2000);
	});

	it('PechbijstandFR: Klik op volgende knop', function () {
		console.log('PechbijstandFR: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
		browser.sleep(2000);
	});

	it('PechbijstandFR: Valideer pagina - stap 2. Gegevens', function () {
		console.log('PechbijstandFR: Valideer pagina - stap 2. Gegevens');
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[2]/div/h2'));
		browser.wait(EC.visibilityOf(ele), 20000, "Timeout of VisibilityOf: Stap 2 van 3: Gegevens");

		console.log('PechbijstandFR: Stap 2. Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 303');
		});
	});

	it('PechbijstandFR: Stap 2. Voer persoonsgegevens in', function () {
		console.log('PechbijstandFR: Stap 2. Voer persoonsgegevens in');
		common.firstName.sendKeys(common.userFirstName);
		common.lastName.sendKeys(common.userLastName);
		common.datepicker.sendKeys(common.userBirthDate);
		browser.sleep(2000);
	});

	it('PechbijstandFR: Stap 2. Voer adresgegegevens in', function () {
		console.log('PechbijstandFR: Stap 2. Voer adresgegegevens in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		browser.sleep(2000);
	});

	it('PechbijstandFR: Stap 2. Voer contactgegegevens in', function () {
		console.log('PechbijstandFR: Stap 2. Voer contactgegegevens in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('PechbijstandFR: Stap 2. Klik checkbox algemene voorwaarden', function () {
		console.log('PechbijstandFR: Stap 2. Klik checkbox algemene voorwaarden');
		common.checkboxGeneralTerms.click();
		browser.sleep(2000);
	});

	it('PechbijstandFR: Klik op volgende knop', function () {
		console.log('PechbijstandFR: Klik op volgende knop');
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('PechbijstandFR: Valideer pagina - stap 3. Betaling', function () {
		console.log('PechbijstandFR: Valideer pagina - stap 3. Betaling');
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form/ul[2]/li[4]/label/div/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 3: Betaling");

		console.log('PechbijstandFR: Stap 3. Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 303');
		});
	});
	if (common.payment) {
		it('Betaalstap selecteer Visa', function () {
			paymentFunctions.visaPayment();
		});
	};
});
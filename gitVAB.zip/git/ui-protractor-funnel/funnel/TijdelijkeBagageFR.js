var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("TijdelijkeBagageFR: Tijdelijke reisverzekering: Bagage", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	it('TijdelijkeBagageFR: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeBagageFR: Open browser & accepteer cookies");
		browser.get(applicationURL + '/fr/assistance/assistance-voyage/assistance-voyage-temporaire/bagages');
		browser.sleep(5000);
		common.cookie.click();
		browser.waitForAngularEnabled(false);
	});

	it('TijdelijkeBagageFR: Valideer prijs', function () {
		console.log("TijdelijkeBagageFR: Valideer prijs");
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: HomePage of Tijdelijke reisbijstand");
		browser.waitForAngular;
		browser.sleep(2000);

		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 0');
		});
	});

	it('TijdelijkeBagageFR: Vul datums in', function () {
		console.log("TijdelijkeBagageFR: Vul datums in");
		console.log('ReisbijstandGezinFR: Vul startdatum in');
		var startDate = dateFunctions.getFutureDate(1, 1);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div[1]/input')).sendKeys(startDate);

		// Wijzig focus door validaties
	 	element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/p')).click();
	 	browser.sleep(2000);

		console.log('ReisbijstandGezinFR: Vul einddatum in');
		var endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 27);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div[1]/input')).sendKeys(endDate);
 		// Wijzig focus door validaties
 		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/p')).click();
 		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Valideer prijs ', function () {
		console.log("TijdelijkeBagageFR: Valideer prijs");
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 28');
		});
	});

	it('TijdelijkeBagageFR: Voeg aantal personen toe', function () {
		console.log("TijdelijkeBagageFR: Voeg aantal personen toe");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 56');
		});
	});

	it('TijdelijkeBagageFR: Voeg bagage prijs toe', function () {
		console.log("TijdelijkeBagageFR: Voeg bagage prijs toe");
		var i;
		var totalLuggage = 11;
		var luggagePrice = 56;
		var addPriceLuggage = 56;

		for (i = 0; i < totalLuggage; i++) {
			element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
			browser.sleep(2000);

			element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
				console.log('TijdelijkeBagageFR: Valideer prijs');
				luggagePrice = luggagePrice + addPriceLuggage;
				expect(defaultPricing).toBe('€ ' + luggagePrice);

				console.log('TijdelijkeBagageFR: luggagePrice = ' + luggagePrice);
			});
		}
	});

	it('TijdelijkeBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeBagageFR: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Valideer nieuwe pagina 1/4', function () {
		console.log("TijdelijkeBagageFR: Valideer nieuwe pagina 1/4");
		/*	var ele = element(by.className("vab__calculator__form__price"));
			browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Valideer nieuwe pagina 1/4");
	*/
		element(by.xpath("/html/body/section[2]/div/app-root/app-dynamic-component/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1")).getText().then(function (defaultTitle) {
			expect(defaultTitle).toBe(common.tijdelijkeBagageTitelFR);
		});
	});

	it('TijdelijkeBagageFR: Vul gegevens in persoon 1', function () {
		console.log("TijdelijkeBagageFR: Vul gegevens in persoon 1");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[2]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Vul gegevens in persoon 2', function () {
		console.log("TijdelijkeBagageFR: Vul gegevens in persoon 2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).sendKeys(common.userFirstName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[2]/input')).sendKeys(common.userLastName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[1]/app-person[2]/div/div[1]/label[2]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Valideer prijs', function () {
		console.log("TijdelijkeBagageFR: Valideer prijs");
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 672');
			browser.sleep(2000);
		});
	});

	it('TijdelijkeBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeBagageFR: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
	});

	it('TijdelijkeBagageFR: Valideer nieuwe pagina 2/4', function () {
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 672');
		});
	});

	it('TijdelijkeBagageFR: Vul adres in', function () {
		console.log("TijdelijkeBagageFR: Vul adres in");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
	});

	it('TijdelijkeBagageFR: Vul email in', function () {
		console.log("TijdelijkeBagageFR: Vul email in");
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeBagageFR: Klik checkbox algemene voorwaarden");
		common.checkbox.click();
	});

	it('TijdelijkeBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeBagageFR: Klik op volgende knop");
		browser.sleep(2000);
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Valideer nieuwe pagina 3/4', function () {
		console.log("TijdelijkeBagageFR: Valideer nieuwe pagina 3/4");
		/*	var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]'));
			browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");
	*/
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 672');
		});
	});

	it('TijdelijkeBagageFR: Vul behoefteanalyse pagina in', function () {
		console.log("TijdelijkeBagageFR: Vul behoefteanalyse pagina in");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Klik op toon resultaat', function () {
		console.log("TijdelijkeBagageFR: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeBagageFR: Valideer resultaat tekst', function () {
		console.log("TijdelijkeBagageFR: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe("Sur base de vos réponses, nous vous recommandons le produit suivant : Formule vacances avec bagages temporaire seul");
		});
	});

	it('TijdelijkeBagageFR: Klik op volgende knop', function () {
		console.log("TijdelijkeBagageFR: Klik op volgende knop");
		browser.sleep(2500);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
	});

	it('TijdelijkeBagageFR: Valideer nieuwe pagina 4/4', function () {
		console.log("TijdelijkeBagageFR: Valideer nieuwe pagina 4/4");
		element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
			expect(text).toBe('Étape 4 sur 4 : Paiement');
		});
	});
	if (common.payment) {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});
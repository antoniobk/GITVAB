var Common = require('./VABCommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("FietsbijstandDuo: Buy a product", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('FietsbijstandDuoFR: Open browser & accepteer cookies', async function () {
        console.log('FietsbijstandDuoFR: Open browser & accepteer cookies');
        browser.get(applicationURL + '/fr/assistance/velo/assistance-velo');
        browser.sleep(2000);
        common.cookie.click();
    });

    it('FietsbijstandDuoFR: Valideer prijs fietsbijstand', async function () {
        console.log('FietsbijstandDuoFR: Valideer prijs fietsbijstand');
        var ele = element(by.className("vab__intro__title vab__heading--2"));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Fietsbijstand homepage");

        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 46');
        });
    });

    it('FietsbijstandDuoFR: Valideer prijs duo bijstand', async function () {
        console.log('FietsbijstandDuoFR: Valideer prijs duo bijstand');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[2]')).click();
        browser.sleep(2000);

        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 77');
        });
    });

    it('FietsbijstandDuoFR: Navigeer volgende pagina', async function () {
        console.log('FietsbijstandDuoFR: Navigeer volgende pagina')

        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
    });

    it('FietsbijstandDuoFR: Valideer nieuwe pagina 1/3', async function () {
        console.log('FietsbijstandDuoFR: Valideer nieuwe pagina 1/3');
        var ele = element(by.className("h1 vab__fs--2 vab__ff--special-1"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout reached");

        element(by.className("h1 vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 1 sur 3 : Votre VAB-Assistance Vélo');
        });
    });

    it('FietsbijstandDuoFR: Valideer prijs', async function () {
        console.log('FietsbijstandDuoFR: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 77');
        });
    });

    it('FietsbijstandDuoFR: Vul details in persoon 1', async function () {
        console.log('FietsbijstandDuoFR: Vul details in persoon 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

        // Validation needs to have focus
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[2]/div/div/label[1]/input')).click();
    });

    it('FietsbijstandDuoFR: Vul details in persoon 2', async function () {
        console.log('FietsbijstandDuoFR: Vul details in persoon 2');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[2]/div/div/label[1]/input')).sendKeys(common.userFirstName + "2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[2]/div/div/label[2]/input')).sendKeys(common.userLastName + "2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

        // Validation needs to have focus
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div/app-person[2]/div/div/label[2]/input')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandDuoFR: Klik volgende knop', async function () {
        console.log('FietsbijstandDuoFR: Klik volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a')).click();
        browser.sleep(2000);
        browser.ignoreSynchronization = true;
    });

    it('FietsbijstandDuoFR: Valideer nieuwe pagina 2/3', async function () {
        console.log('FietsbijstandDuoFR: Valideer nieuwe pagina 2/3');
        var ele = element(by.className("vab__fs--2 vab__ff--special-1"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout reached");

        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 2 sur 3 : Données');
        });
    });

    it('FietsbijstandDuoFR: Valideer prijs', async function () {
        console.log('FietsbijstandDuoFR: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 77');
        });
    });

    it('FietsbijstandDuoFR: Vul adres in', async function () {
        console.log('FietsbijstandDuoFR: Vul adres in');
        element(by.id('PersonalDataViewModel_AddressViewModel_ZipCode')).sendKeys(common.userZipcode);
        element(by.id('PersonalDataViewModel_AddressViewModel_City')).sendKeys(common.userCity);
        element(by.id('PersonalDataViewModel_AddressViewModel_Street')).sendKeys(common.userStreet);
        element(by.id('PersonalDataViewModel_AddressViewModel_Number')).sendKeys(common.userHouseNumber);
    });

    it('FietsbijstandDuoFR: Vul email in', async function () {
        console.log('FietsbijstandDuoFR: Vul email in');
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).sendKeys(common.userEmail);

    });

    it('FietsbijstandDuoFR: Klik checkbox bevestiging', async function () {
        console.log('FietsbijstandDuoFR: Klik checkbox bevestiging');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[1]')).click();
        browser.sleep('250');
    });

    it('FietsbijstandDuoFR: Klik op volgende knop', async function () {
        console.log('FietsbijstandDuoFR: Klik op volgende knop');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div/button[2]/span')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandDuoFR: Valideer nieuwe pagina 3/3', async function () {
        console.log('FietsbijstandDuoFR: Valideer nieuwe pagina 3/3');
        var ele = element(by.xpath("/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout reached");

        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 3 sur 3 : Paiement');
        });
    });

    it('FietsbijstandDuoFR: Valideer prijs', async function () {
        console.log('FietsbijstandDuoFR: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 77');
        });
    });
    if (common.payment) {
        it('Betaalstap selecteer Visa', function () {
            paymentFunctions.visaPayment();
        });
    };
});
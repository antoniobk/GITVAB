var Common = require('./VABcommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("FietsverzekeringNL: Buy a product", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('FietsverzekeringNL: Open browser & accepteer cookies', function () {
        console.log("FietsverzekeringNL: Open browser & accepteer cookies");
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/fiets/fietsverzekering');
        browser.sleep(3000);

        //TODO: Check if this is still necessary:
        //Fix is necessary for automatic play of movie on page
        //browser.actions().mouseMove(element(by.xpath('//*[@id="page-container"]/div/div/app-funnel-options/div[1]/div/ul/li/span'))).perform();
        //browser.sleep(3000);

        common.cookie.click();
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Vul gegevens stadsfiets in', function () {
        console.log("FietsverzekeringNL: Vul gegevens stadsfiets in");
        var ele = element(by.className('vab__calculator__form__theHeading'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Fietsverzekering homepage");

        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[3]/app-textinput/div/label/div[2]/div/div/input')).sendKeys('600');
        browser.sleep(3000);

        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[2]/app-radiobuttonlist/div/div[2]/div/div/label/span[2]')).click();
        browser.sleep(3000);

        var purchaseDate = dateFunctions.getFutureDate(1, 0);
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[1]/app-dateinput/div/label/div[2]/app-material-datepicker/div/input')).sendKeys(purchaseDate);
        browser.sleep(3000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/app-product-option/div/div/div/div/div[2]/app-radiobuttonlist/div/div[2]/div/div/label/span[2]')).click();
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Valideer prijs', function () {
        console.log("FietsverzekeringNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 57');
            browser.sleep(3000);
        });
    });

    it('FietsverzekeringNL: Klik op Bestel Online knop', function () {
        console.log("FietsverzekeringNL: Klik op Bestel Online knop");
        element(by.xpath('//*[@id="page-container"]/app-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
        browser.sleep(3000);

        console.log("FietsverzekeringNL: Ignore synchronization");
        browser.ignoreSynchronization = true;
    });

    it('FietsverzekeringNL: Valideer nieuwe pagina 1/4', function () {
        console.log("FietsverzekeringNL: Valideer nieuwe pagina 1/4");
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: pagina 1/4");

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 1 van 4: Jouw VAB-Fietsverzekering');
        });
    });

    it('FietsverzekeringNL: Framenummer invullen', function () {
        console.log("FietsverzekeringNL: Framenummer invullen");
        browser.waitForAngularEnabled(false);
        browser.sleep(2000);

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-collapsed-detail/ul/div[1]/app-collapsible-area/li/div[2]/div/div/div/div[1]/app-textinput/div/div/label/div[2]/div/div/div/input')).sendKeys('123456');
    });

    it('FietsverzekeringNL: Valideer of prijs nog hetzelfde is', function () {
        console.log("FietsverzekeringNL: Valideer of prijs nog hetzelfde is");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 57');
        });
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Klik op volgende knop bij pagina 1 van 4', function () {
        console.log("FietsverzekeringNL: Klik op volgende knop bij pagina 1 van 4");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Valideer nieuwe pagina 2/4', function () {
        console.log("FietsverzekeringNL: Valideer nieuwe pagina 2/4");
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: pagina 2/4");

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 2 van 4: Gegevens');
        });
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Vul gegevens in persoon 1', function () {
        console.log("FietsverzekeringNL: Vul gegevens in persoon 1");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[2]/span/span/app-textinput/div/div/label/div/input')).sendKeys(common.userFirstName);
        browser.sleep(3000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[3]/span/span/app-textinput/div/div/label/div/input')).sendKeys(common.userLastName);
        browser.sleep(3000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[4]/span/span/app-dateinput/div/div/label/div[1]/app-material-datepicker/div/input')).sendKeys(common.userBirthDate);
        browser.sleep(3000);
        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[1]/div[2]/div[3]/span/span/app-textinput/div/div/label/div/input')).click();
        browser.sleep(3000);

    });

    it('FietsverzekeringNL: Vul adres in persoon 1', function () {
        console.log("FietsverzekeringNL: Vul adres in persoon 1");
        // Validation needs to have sleep behind each field
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[1]/span[1]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userZipcode);
        browser.sleep(3000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[1]/span[2]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userCity);
        browser.sleep(3000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[2]/span[1]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userStreet);
        browser.sleep(3000);
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div[2]/div[2]/div[2]/span[2]/span/app-textinput/div/div/label/div/input')).sendKeys(common.userHouseNumber);
        browser.sleep(3000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/div/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div[1]/div[3]/p')).click();
        browser.sleep(3000)
    });

    it('FietsverzekeringNL: Vul email in persoon 1', function () {
        console.log("FietsverzekeringNL: Vul email in persoon 1");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[4]/div[1]/div[2]/div[1]/span/span/app-emailinput/div/div/label/div/input')).sendKeys(common.userEmail);
        browser.sleep(3000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/div/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div[1]/div[3]/p')).click();
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Klik checkbox algemene voorwaarden', function () {
        console.log("FietsverzekeringNL: Klik op checkbox algemene voorwaarden");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[4]/div[2]/div/div[1]/span/span/app-checkbox/div/label/span[1]')).click();
        browser.sleep(4000);
    });

    it('FietsverzekeringNL: Klik op volgende knop', function () {
        console.log("FietsverzekeringNL: Klik op volgende knop");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[3]/div/a[2]/span')).click();
        browser.sleep(4000);
    });

    it('FietsverzekeringNL: Valideer nieuwe pagina 3/4', function () {
        console.log("FietsverzekeringNL: Valideer nieuwe pagina 3/4");
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[1]/span/app-question/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

        browser.sleep(3000);

        console.log("FietsverzekeringNL: Next page");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 3 van 4: Behoefteanalyse');
        });
    });

    it('FietsverzekeringNL: Vul de behoefteanalyse in', function () {
        console.log("FietsverzekeringNL: Vul de behoefteanalyse in");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[1]/span/app-question/div/label[1]/span[1]')).click();
        browser.sleep(3000);

        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/app-section-detail/div/div[3]/div/div/div[2]/span/app-question/div/label[1]/span[1]')).click();
        browser.sleep(3000);
    });

    it('FietsverzekeringNL: Klik op volgende knop', function () {
        console.log("FietsverzekeringNL: Klik op volgende knop");
        var nextBtn = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[3]/div/a[2]'));
        browser.wait(EC.visibilityOf(nextBtn), 50000, "Timeout of VisibilityOf: Wait till next button appears");

        nextBtn.click();
        browser.sleep(3000);

    });

    it('FietsverzekeringNL: Valideer nieuwe pagina 4/4', function () {
        console.log("FietsverzekeringNL: Valideer nieuwe pagina 4/4");
        var ele = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: pagina 4/4");

        var myElement = element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p'));
        expect(myElement.isPresent()).toBe(true);

        console.log("FietsverzekeringNL: Next page");
        element(by.xpath('//*[@id="page-container"]/div/div/div/div/div/div/div/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 4 van 4: Betaling');
        });
    });

    it('FietsverzekeringNL: Valideer prijs', function () {
        console.log("FietsverzekeringNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 57');
            browser.sleep(5000);
        });
    });
    if (common.payment) {

        it('Betaalstap selecteer MC', function () {
            paymentFunctions.masterCardFiets();
        });
    }
});